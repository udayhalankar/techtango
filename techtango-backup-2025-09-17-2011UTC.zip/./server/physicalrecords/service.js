module.exports = {
async search({ text }) {
// TODO: replace with DB. Returning demo rows matching your screenshot columns.
return {
items: [
{ id: 1, fileId: "TM-FIN-F2345", departmentFileId: "Budget 1 — 2022", boxId: "TM-FIN-B23", dateCreated: "21 July 2022", status: "IN", custodian: "RECORDS", requestType: "SERVICE", objectId: 1004, owner: "Uday Halankar", category: "Finance", period: "Jan to Mar 23", recordsManager: "Uday Halankar", recordsClassification: "Finance Records" },
],
};
},
async submit(payload) { return { ok: true, submitted: payload?.ids?.length || 0 }; },
async getRequest(id) { return { id, history: [] }; },
async processService(id, body) { return { ok: true, id, type: "SERVICE" }; },
async processMaterial(id, body) { return { ok: true, id, type: "MATERIAL" }; },
async inwardBoxes(body) { return { ok: true }; },
async inwardFiles(body) { return { ok: true }; },
async register(body) { return { ok: true, id: 1234 }; },
};