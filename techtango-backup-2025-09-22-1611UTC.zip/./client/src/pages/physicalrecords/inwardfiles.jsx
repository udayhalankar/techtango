import React from "react";
import { Card, CardContent, Typography } from "@mui/material";


export default function InwardFiles(){
return (
<Card><CardContent>
<Typography variant="h6">Inward Files</Typography>
<Typography variant="body2">Placeholder for inwarding individual files flow.</Typography>
</CardContent></Card>
);
}