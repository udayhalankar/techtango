import React from 'react';
// import Chartrender from '../../components/chartBox/xChartrender';
import ChartBox from '../../components/chartBox/ChartBox';

export const Dms = () => {
  return (
    <div>dms

<ChartBox />
    </div>
   
  )
}

export default Dms;
