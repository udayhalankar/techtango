// server/physicalrecords/rmassignments/service.js
const db = require("../../db");
const notify = require("./notify/service"); // you said notify is under rmassignments/notify

function generateOtp(len = 5) {
  const min = Math.pow(10, len - 1);
  const max = Math.pow(10, len) - 1;
  return String(Math.floor(min + Math.random() * (max - min))); // e.g., 23456
}

function formatPhone(mobile) {
  // expect "91-9999900000" -> "+91 9999900000"
  if (!mobile) return null;
  const [cc, num] = String(mobile).split("-");
  return cc && num ? `+${cc.trim()} ${num.trim()}` : mobile;
}

async function search({
  text = "",
  requestId,
  taskName,
  assignmentStatus,
  userAssignedTo,
  dateFrom,
  dateTo,
  page = 1,
  pageSize = 10,
  sortBy = "date_assigned",
  sortDir = "desc",
}) {
  const allowedSort = new Set(["date_assigned", "assignment_status", "task_name", "id", "request_id"]);
  if (!allowedSort.has(sortBy)) sortBy = "date_assigned";
  sortDir = String(sortDir).toLowerCase() === "asc" ? "asc" : "desc";

  const where = [];
  const params = [];
  let i = 1;

  if (text) { where.push(`(comments ILIKE $${i} OR assigned_by ILIKE $${i} OR user_assigned_to_name ILIKE $${i})`); params.push(`%${text}%`); i++; }
  if (requestId) { where.push(`request_id = $${i}`); params.push(Number(requestId)); i++; }
  if (taskName) { where.push(`task_name = $${i}`); params.push(taskName); i++; }
  if (assignmentStatus) { where.push(`assignment_status = $${i}`); params.push(assignmentStatus); i++; }
  if (userAssignedTo) { where.push(`user_assigned_to = $${i}`); params.push(Number(userAssignedTo)); i++; }
  if (dateFrom) { where.push(`date_assigned >= $${i}`); params.push(dateFrom); i++; }
  if (dateTo) { where.push(`date_assigned < $${i}`); params.push(dateTo); i++; }

  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const countSql = `SELECT COUNT(*)::int AS cnt FROM public.rm_assignments ${whereSql}`;
  const { rows: cntRows } = await db.query(countSql, params);
  const total = cntRows[0]?.cnt || 0;
  const offset = Math.max(0, (page - 1) * pageSize);

  const listSql = `
    SELECT
      id, request_id, task_name, user_assigned_to, user_assigned_to_name,
      otp, assignment_status, date_assigned, assigned_by, comments,
      date_created, date_modified, created_by, modified_by
    FROM public.rm_assignments
    ${whereSql}
    ORDER BY ${sortBy} ${sortDir}
    LIMIT $${i} OFFSET $${i + 1}
  `;
  const { rows } = await db.query(listSql, [...params, pageSize, offset]);
  return { items: rows, page, pageSize, total, hasMore: offset + rows.length < total };
}

async function create(body, reqUser) {
  // 1) Resolve assignee details (for notification + display name)
  let assignee = null;
  if (body.userAssignedTo) {
    const { rows } = await db.query(
      `SELECT id, name, mobile, email FROM public.rmteam WHERE id = $1`,
      [body.userAssignedTo]
    );
    assignee = rows[0] || null;
  }

  // 2) OTP (generate if not provided)
  const otp = body.otp ?? generateOtp(5);

  // 3) Insert assignment (default status 'Assigned'), include audit columns if present
  const q = `
    INSERT INTO public.rm_assignments
      (request_id, task_name, user_assigned_to, user_assigned_to_name,
       otp, assignment_status, assigned_by, comments, created_by, modified_by)
    VALUES ($1,$2,$3,$4,$5,COALESCE($6,'Assigned'),$7,$8,$9,$9)
    RETURNING id, date_assigned
  `;
  const p = [
    body.requestId,
    body.taskName,
    body.userAssignedTo ?? null,
    body.userAssignedToName ?? (assignee?.name || null),
    otp,
    body.assignmentStatus,                  // undefined -> COALESCE to 'Assigned'
    reqUser?.id ?? body.assignedBy ?? null, // who assigned
    body.comments ?? null,
    reqUser?.id ?? null,
  ];
  const { rows } = await db.query(q, p);
  const id = rows[0].id;

  // 4) Notify assignee (best-effort)
  try {
    if (assignee) {
      const prettyPhone = formatPhone(assignee.mobile);
      const msg = `Task assigned: ${body.taskName} for Request #${body.requestId}. OTP: ${otp}`;
      if (prettyPhone) await notify.sendSms(prettyPhone, msg);
      if (assignee.email) await notify.sendEmail(assignee.email, "Task Assigned", msg);
    }
  } catch (e) {
    console.error("notify failed", e); // don't fail the API
  }

  return { ok: true, id, dateAssigned: rows[0].date_assigned };
}

async function getById(id) {
  const { rows } = await db.query(`SELECT * FROM public.rm_assignments WHERE id = $1`, [id]);
  return rows[0] || null;
}

async function patch(id, body) {
  const sets = [];
  const params = [];
  let i = 1;

  const map = {
    task_name: body.taskName,
    user_assigned_to: body.userAssignedTo,
    user_assigned_to_name: body.userAssignedToName,
    otp: body.otp,
    assignment_status: body.assignmentStatus,
    assigned_by: body.assignedBy,
    comments: body.comments,
    modified_by: body.modifiedBy,
  };
  Object.entries(map).forEach(([col, val]) => {
    if (val !== undefined) { sets.push(`${col} = $${i++}`); params.push(val); }
  });
  if (!sets.length) return { ok: true, updated: 0 };

  const sql = `UPDATE public.rm_assignments SET ${sets.join(", ")}, date_modified = NOW() WHERE id = $${i}`;
  params.push(id);
  const { rowCount } = await db.query(sql, params);
  return { ok: true, updated: rowCount };
}

async function updateStatus(id, assignmentStatus) {
  const { rowCount } = await db.query(
    `UPDATE public.rm_assignments SET assignment_status = $1, date_modified = NOW() WHERE id = $2`,
    [assignmentStatus, id]
  );
  return { ok: true, updated: rowCount };
}

async function verifyOtp(id, code, req) {
  const { rows } = await db.query(
    `SELECT id, otp, assignment_status FROM public.rm_assignments WHERE id = $1`,
    [id]
  );
  if (!rows[0]) throw new Error("Assignment not found");

  const ok = String(rows[0].otp) === String(code);

  // audit attempt
  await db.query(
    `INSERT INTO public.rm_assignment_otp_audit
       (assignment_id, attempted_otp, success, source, user_id, user_ip)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [id, String(code), ok, "api", req?.user?.id ?? null, req?.ip ?? null]
  );

  if (!ok) return { ok: false, error: "Invalid OTP" };

  // on success -> Accepted
  const { rowCount } = await db.query(
    `UPDATE public.rm_assignments
       SET assignment_status = 'Accepted', modified_by = $2, date_modified = NOW()
     WHERE id = $1`,
    [id, req?.user?.id ?? null]
  );

  return { ok: true, updated: rowCount };
}

async function remove(id) {
  const { rowCount } = await db.query(`DELETE FROM public.rm_assignments WHERE id = $1`, [id]);
  return { ok: true, deleted: rowCount };
}

module.exports = {
  search,
  create,
  getById,
  patch,
  updateStatus,
  verifyOtp,
  remove,
};
