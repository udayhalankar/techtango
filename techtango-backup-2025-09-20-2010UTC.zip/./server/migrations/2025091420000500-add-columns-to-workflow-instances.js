// migrations/XXXXXXXXXXXXXX-add-columns-to-workflow-instances.js
'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.sequelize.transaction(async (t) => {
      await queryInterface.addColumn('workflow_instances', 'step_name', {
        type: Sequelize.TEXT,
        allowNull: true,
      }, { transaction: t });

      await queryInterface.addColumn('workflow_instances', 'assigned_to', {
        type: Sequelize.INTEGER, // or BIGINT if your user ids exceed 2^31-1
        allowNull: true,
      }, { transaction: t });

      await queryInterface.addColumn('workflow_instances', 'step_due_date', {
        type: Sequelize.DATE, // stores timestamp in PG
        allowNull: true,
      }, { transaction: t });

      await queryInterface.addColumn('workflow_instances', 'updateform_id', {
        type: Sequelize.INTEGER,
        allowNull: true,
      }, { transaction: t });

      // Helpful indexes for filtering
      await queryInterface.addIndex('workflow_instances', ['assigned_to'], {
        name: 'idx_wi_assigned_to',
        transaction: t,
      });
      await queryInterface.addIndex('workflow_instances', ['step_due_date'], {
        name: 'idx_wi_step_due_date',
        transaction: t,
      });
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.sequelize.transaction(async (t) => {
      await queryInterface.removeIndex('workflow_instances', 'idx_wi_step_due_date', { transaction: t });
      await queryInterface.removeIndex('workflow_instances', 'idx_wi_assigned_to', { transaction: t });

      await queryInterface.removeColumn('workflow_instances', 'updateform_id', { transaction: t });
      await queryInterface.removeColumn('workflow_instances', 'step_due_date', { transaction: t });
      await queryInterface.removeColumn('workflow_instances', 'assigned_to', { transaction: t });
      await queryInterface.removeColumn('workflow_instances', 'step_name', { transaction: t });
    });
  }
};
