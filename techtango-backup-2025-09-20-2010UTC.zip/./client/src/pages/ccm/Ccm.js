import React from 'react';
import "./ccm.scss";

export const Ccm = () => {
  return (
    <div>Company Corespondence Management</div>
  )
}

export default Ccm;
