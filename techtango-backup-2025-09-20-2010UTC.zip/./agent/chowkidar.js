// agent/chowkidar.js
'use strict';

const path = require('path');
const fs = require('fs');

const { scanAll } = require('./scanner');
const { buildGraph } = require('./graphBuilder');

(async () => {
  const debug = process.argv.includes('--debug');
  const noGraph = process.argv.includes('--no-graph');

  try {
    console.log('🛡️  Chowkidar 1.0: starting scan…');

    // 1) Run best-practice checks
    const report = await scanAll({ debug });

    const resultsFile = path.join(__dirname, 'results.json');
    fs.writeFileSync(resultsFile, JSON.stringify(report, null, 2));

    const filesCount  = Object.keys(report.results || {}).length;
    const checksCount = Object.keys(report.summary?.byCheck || {}).length;

    console.log(`✅ Scan complete. Files: ${filesCount}, Checks: ${checksCount}`);
    console.log(`   Output: ${path.relative(process.cwd(), resultsFile)}`);

    // 2) Build dependency/route graph (optional)
    if (noGraph) return;

    try {
      const projectRoot = path.resolve(__dirname, '..');
      const graph = await buildGraph(projectRoot);

      const graphFile = path.join(__dirname, 'graph.json');
      fs.writeFileSync(graphFile, JSON.stringify(graph, null, 2));
      console.log(`🔗 Graph built: ${graph.nodes.length} nodes, ${graph.edges.length} edges`);
      console.log(`   Output: ${path.relative(process.cwd(), graphFile)}`);

      if (graph.errors?.length) {
        const errFile = path.join(__dirname, 'graph-errors.json');
        fs.writeFileSync(errFile, JSON.stringify(graph.errors, null, 2));
        const sample = graph.errors.slice(0, 3).map(e => `${e.file}: ${e.error}`).join('\n  • ');
        console.warn(
          `⚠️  Parser/read issues in ${graph.errors.length} file(s). ` +
          `Saved to ${path.relative(process.cwd(), errFile)}\n  • ${sample}`
        );
      }
    } catch (e) {
      console.warn(`⚠️  Skipping graph build: ${e.message}`);
      console.warn('    Tip: npm i -D fast-glob @babel/parser @babel/traverse @babel/types');
    }
  } catch (err) {
    console.error('❌ Scan failed:', err);
    process.exit(1);
  }
})();
