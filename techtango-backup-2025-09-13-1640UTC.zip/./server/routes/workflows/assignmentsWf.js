// server/routes/workflows/assignmentswf.js
const express = require('express');
const router = express.Router();
const pool = require('../../db');
const { verifyToken } = require('../../middleware/authMiddleware');

// Require a valid JWT for every route here
router.use(verifyToken);

// tiny query helper
async function q(sql, params = []) {
  const { rows } = await pool.query(sql, params);
  return rows;
}

/**
 * Decide how to scope results to the current user.
 * Priority:
 *   1) assignee_id (compare as text to avoid int/varchar mismatch)
 *   2) assignee_email (if token has email)
 * You can disable scoping via query ?all=1 for quick debugging.
 */
function buildAssigneeScope(req) {
  const { all } = req.query || {};
  if (all === '1' || all === 'true') {
    return { where: '', params: [] };
  }

  const userId =
    req.user?.userId ??
    req.user?.id ??
    null;

  const email =
    req.user?.email ??
    req.user?.user_email ??
    req.user?.mail ??
    null;

  // Prefer assignee_id if we have a numeric/ID user id
  if (userId != null && userId !== '') {
    return {
      where: 'WHERE t.assignee_id::text = $1::text',
      params: [String(userId)],
    };
  }

  // Fall back to email
  if (email) {
    return {
      where: 'WHERE t.assignee_email = $1',
      params: [email],
    };
  }

  // No way to scope — return nothing rather than everything
  return { where: 'WHERE 1=0', params: [] };
}

/* -------------------------------------------------
 * QUICK DIAGNOSTIC: see what your token exposes
 * ------------------------------------------------- */
router.get('/whoami', (req, res) => {
  res.json({ user: req.user ?? null });
});

/* -------------------------------------------------
 * SUPER-SIMPLE INBOX
 * Returns tasks from workflow_tasks in a shape that
 * the current UI can already render (placeholders
 * for fields we don't have without joins).
 * ------------------------------------------------- */
router.get('/inbox', async (req, res) => {
  try {
    const { where, params } = buildAssigneeScope(req);

    // Show tasks that are not completed, or show all if you'd like.
    // Using completed_at to infer completion; keep it simple.
    const sql = `
      SELECT
        t.id                                 AS task_id,
        t.instance_id                        AS instance_id,
        t.node_id                            AS node_id,
        t.node_type                          AS node_type,
        t.form_id                            AS form_id,
        t.status                             AS task_status,
        t.assignee_id                        AS assignee_id,
        t.assignee_email                     AS assignee_email,
        COALESCE(t.started_at, t.created_at, t.updated_at, NOW()) AS started_at,

        -- Fields expected by your React page; keep placeholders to avoid joins
        NULL::text                           AS instance_status,
        NULL::int                            AS record_id,
        'Workflow'                           AS workflow_name
      FROM workflow_tasks t
      ${where}
      -- If you want to hide completed ones, uncomment next line:
      -- ${where ? 'AND' : 'WHERE'} (t.completed_at IS NULL)
      ORDER BY started_at DESC
      LIMIT 200
    `;

    const rows = await q(sql, params);
    res.json(rows);
  } catch (err) {
    console.error('GET /inbox error:', err);
    res.status(500).json({ error: 'Failed to fetch inbox' });
  }
});

/* -------------------------------------------------
 * SUPER-SIMPLE OUTBOX
 * "Workflows I have started" — without touching other
 * tables, we approximate by grouping tasks per instance
 * where YOU created the first task (created_by).
 * If your JWT carries only email, we also try assignee_email
 * as a fallback signal.
 *
 * If you *do* have a workflow_instances table with a
 * `started_by` column, we can switch to that later.
 * ------------------------------------------------- */
function buildCreatorScope(req) {
  const { all } = req.query || {};
  if (all === '1' || all === 'true') {
    return { clause: '', params: [] };
  }

  const userId =
    req.user?.userId ??
    req.user?.id ??
    null;

  const email =
    req.user?.email ??
    req.user?.user_email ??
    req.user?.mail ??
    null;

  if (userId != null && userId !== '') {
    return { clause: 't.created_by::text = $1::text', params: [String(userId)] };
  }
  if (email) {
    // fallback: instances where at least one task has your email as assignee_email
    return { clause: 't.assignee_email = $1', params: [email] };
  }

  // No identity → return none
  return { clause: '1=0', params: [] };
}

router.get('/outbox', async (req, res) => {
  try {
    const { clause, params } = buildCreatorScope(req);

    // We pick the earliest task per instance_id created by "you"
    // and treat that as the "started_at" for your outbox card.
    const sql = `
      WITH mine AS (
        SELECT
          t.instance_id,
          MIN(COALESCE(t.started_at, t.created_at, t.updated_at, NOW())) AS started_at
        FROM workflow_tasks t
        WHERE ${clause}
        GROUP BY t.instance_id
      )
      SELECT
        m.instance_id,
        m.started_at,
        -- Placeholders/UI fields
        NULL::text AS instance_status,
        'Workflow' AS workflow_name
      FROM mine m
      ORDER BY m.started_at DESC
      LIMIT 200
    `;

    const rows = await q(sql, params);
    res.json(rows);
  } catch (err) {
    console.error('GET /outbox error:', err);
    res.status(500).json({ error: 'Failed to fetch outbox' });
  }
});

/* -------- Optional namespaced aliases (same handlers) -------- */
router.get('/workflows/assignments/inbox', (req, res, next) => router.handle({ ...req, url: '/inbox' }, res, next));
router.get('/workflows/assignments/outbox', (req, res, next) => router.handle({ ...req, url: '/outbox' }, res, next));

module.exports = router;



// // server/routes/workflows/assignmentswf.js
// const express = require('express');
// const router = express.Router();

// const pool = require('../../db');
// const { verifyToken } = require('../../middleware/authMiddleware');

// // 🔒 Require a valid JWT for everything in here
// router.use(verifyToken);

// // ---- tiny query helper (with logging on error)
// async function q(text, params = []) {
//   try { return await pool.query(text, params); }
//   catch (err) {
//     console.error('PG ERROR:\nSQL:\n', text, '\nPARAMS:', params, '\nERR:', err);
//     throw err;
//   }
// }

// // ---- metadata helpers (cache simple checks)
// const tblCache = new Map();
// const colCache = new Map();

// async function tableExists(name) {
//   if (tblCache.has(name)) return tblCache.get(name);
//   const sql = `
//     SELECT 1 
//     FROM information_schema.tables 
//     WHERE table_schema='public' AND table_name=$1 LIMIT 1
//   `;
//   const ok = !!(await q(sql, [name])).rowCount;
//   tblCache.set(name, ok);
//   return ok;
// }
// async function colExists(table, col) {
//   const key = `${table}|${col}`;
//   if (colCache.has(key)) return colCache.get(key);
//   const sql = `
//     SELECT 1 
//     FROM information_schema.columns 
//     WHERE table_schema='public' AND table_name=$1 AND column_name=$2 LIMIT 1
//   `;
//   const ok = !!(await q(sql, [table, col])).rowCount;
//   colCache.set(key, ok);
//   return ok;
// }
// async function firstExistingCol(table, candidates) {
//   for (const c of candidates) if (await colExists(table, c)) return c;
//   return null;
// }

// /* ---------------------------------------------
//  * INBOX  (tasks assigned to the logged-in user)
//  * --------------------------------------------- */
// async function queryInbox(userId) {
//   if (!(await tableExists('workflow_tasks')) || !(await tableExists('workflow_instances'))) {
//     throw new Error('Required tables (workflow_tasks/workflow_instances) not found');
//   }

//   const assigneeCol     = (await firstExistingCol('workflow_tasks', ['assignee_id','assigned_to','assignee'])) || 'assignee_id';
//   const taskStatusCol   = await firstExistingCol('workflow_tasks', ['status','task_status']);
//   const taskFormIdCol   = (await colExists('workflow_tasks', 'form_id')) ? 'form_id' : null;
//   const taskNodeIdCol   = (await colExists('workflow_tasks', 'node_id')) ? 'node_id' : null;
//   const taskNodeTypeCol = await firstExistingCol('workflow_tasks', ['node_type','type']);

//   const instStatusCol   = await firstExistingCol('workflow_instances', ['status','instance_status']);
//   const instStartedCol  = (await colExists('workflow_instances','started_at')) ? 'started_at'
//                           : (await colExists('workflow_instances','created_at')) ? 'created_at' : null;
//   const masterRowIdCol  = (await colExists('workflow_instances','master_row_id')) ? 'master_row_id'
//                           : (await colExists('workflow_instances','record_id')) ? 'record_id' : null;

//   const haveWorkflows   = await tableExists('workflows');
//   const wfNameExpr      = haveWorkflows && (await colExists('workflows','name')) ? 'w.name' : `'Workflow'`;

//   const selectParts = [
//     't.id AS task_id',
//     't.instance_id',
//     taskNodeIdCol     ? `t.${taskNodeIdCol} AS node_id`       : `NULL::text  AS node_id`,
//     taskNodeTypeCol   ? `t.${taskNodeTypeCol} AS node_type`   : `NULL::text  AS node_type`,
//     taskFormIdCol     ? `t.${taskFormIdCol} AS form_id`       : `NULL::int   AS form_id`,
//     instStatusCol     ? `i.${instStatusCol} AS instance_status` : `NULL::text AS instance_status`,
//     masterRowIdCol    ? `i.${masterRowIdCol} AS record_id`    : `NULL::int   AS record_id`,
//     `${wfNameExpr} AS workflow_name`,
//   ];

//   // started_at: avoid COALESCE type-mismatch by selecting one branch in JS
//   const startedExpr = instStartedCol ? `i.${instStartedCol}` : `NOW()`;
//   selectParts.push(`${startedExpr} AS started_at`);

//   const joins = [
//     'JOIN workflow_instances i ON i.id = t.instance_id',
//     ...(haveWorkflows ? ['LEFT JOIN workflows w ON w.id = i.workflow_id'] : []),
//   ];

//   const where = [
//     `t.${assigneeCol} = $1`,
//     ...(taskStatusCol ? [`(t.${taskStatusCol} IS NULL OR t.${taskStatusCol} IN ('NEW','PENDING','ASSIGNED','OPEN','IN_PROGRESS'))`] : []),
//   ];

//   const orderBy = instStartedCol ? `i.${instStartedCol}` : 't.id';

//   const sql = `
//     SELECT ${selectParts.join(', ')}
//     FROM workflow_tasks t
//     ${joins.join('\n')}
//     WHERE ${where.join(' AND ')}
//     ORDER BY ${orderBy} DESC
//     LIMIT 200
//   `;

//   const { rows } = await q(sql, [userId]);
//   return rows;
// }

// /* ---------------------------------------------
//  * OUTBOX (instances started by the logged-in user)
//  * --------------------------------------------- */
// async function queryOutbox(userId) {
//   if (!(await tableExists('workflow_instances'))) {
//     throw new Error('Required table workflow_instances not found');
//   }

//   const startedByCol   = await firstExistingCol('workflow_instances', ['started_by','created_by','owner_id','user_id']);
//   const instStatusCol  = await firstExistingCol('workflow_instances', ['status','instance_status']);
//   const instStartedCol = (await colExists('workflow_instances','started_at')) ? 'started_at'
//                         : (await colExists('workflow_instances','created_at')) ? 'created_at' : null;
//   const masterRowCol   = (await colExists('workflow_instances','master_row_id')) ? 'master_row_id'
//                         : (await colExists('workflow_instances','record_id')) ? 'record_id' : null;

//   const haveWorkflows  = await tableExists('workflows');
//   const wfNameExpr     = haveWorkflows && (await colExists('workflows','name')) ? 'w.name' : `'Workflow'`;

//   if (!startedByCol) {
//     // hard fail if we cannot scope to the current user
//     throw new Error('workflow_instances has no started_by/created_by/owner_id/user_id column to scope by user');
//   }

//   const selectParts = [
//     'i.id AS instance_id',
//     instStatusCol  ? `i.${instStatusCol} AS instance_status` : `NULL::text AS instance_status`,
//     masterRowCol   ? `i.${masterRowCol} AS master_row_id`    : `NULL::int  AS master_row_id`,
//     `${wfNameExpr} AS workflow_name`,
//   ];
//   const startedExpr = instStartedCol ? `i.${instStartedCol}` : `NOW()`;
//   selectParts.push(`${startedExpr} AS started_at`);

//   const joins = [
//     ...(haveWorkflows ? ['LEFT JOIN workflows w ON w.id = i.workflow_id'] : []),
//   ];

//   const orderBy = instStartedCol ? `i.${instStartedCol}` : 'i.id';

//   const sql = `
//     SELECT ${selectParts.join(', ')}
//     FROM workflow_instances i
//     ${joins.join('\n')}
//     WHERE i.${startedByCol} = $1
//     ORDER BY ${orderBy} DESC
//     LIMIT 200
//   `;

//   const { rows } = await q(sql, [userId]);
//   return rows;
// }

// /* -------------- Routes -------------- */

// router.get('/inbox', async (req, res) => {
//   try {
//     const userId = req.user?.userId || req.user?.id;
//     if (!userId) return res.status(400).json({ error: 'Missing user id' });
//     res.json(await queryInbox(userId));
//   } catch (err) {
//     console.error('GET /inbox error:', err);
//     res.status(500).json({ error: 'Failed to fetch inbox' });
//   }
// });

// router.get('/outbox', async (req, res) => {
//   try {
//     const userId = req.user?.userId || req.user?.id;
//     if (!userId) return res.status(400).json({ error: 'Missing user id' });
//     res.json(await queryOutbox(userId));
//   } catch (err) {
//     console.error('GET /outbox error:', err);
//     res.status(500).json({ error: 'Failed to fetch outbox' });
//   }
// });

// // Optional namespaced aliases
// router.get('/workflows/assignments/inbox', async (req, res) => {
//   try {
//     const userId = req.user?.userId || req.user?.id;
//     if (!userId) return res.status(400).json({ error: 'Missing user id' });
//     res.json(await queryInbox(userId));
//   } catch (err) {
//     console.error('GET /workflows/assignments/inbox error:', err);
//     res.status(500).json({ error: 'Failed to fetch inbox' });
//   }
// });

// router.get('/workflows/assignments/outbox', async (req, res) => {
//   try {
//     const userId = req.user?.userId || req.user?.id;
//     if (!userId) return res.status(400).json({ error: 'Missing user id' });
//     res.json(await queryOutbox(userId));
//   } catch (err) {
//     console.error('GET /workflows/assignments/outbox error:', err);
//     res.status(500).json({ error: 'Failed to fetch outbox' });
//   }
// });

// module.exports = router;
