import React from "react";
import { Card, CardContent, Typography } from "@mui/material";


export default function ManageRequest() {
return (
<Card><CardContent>
<Typography variant="h6">Manage Requests</Typography>
<Typography variant="body2">(Coming next: filters, queues, and actions)</Typography>
</CardContent></Card>
);
}