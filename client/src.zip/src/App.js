import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProtectedRoute from './components/ProtectedRoute'; // ✅ import
import './App.css';
import Navbar from './components/navbar/Navbar';
import Bpm from "./pages/bpm/Bpm";
import Home from "./pages/home/Home";
import Dashboardmain from "./pages/dashboardmain/Dashboardmain";
import Dak from "./pages/dak/Dak";
import Sbforms from "./pages/sbforms/Sbforms";
import Cm from "./pages/cm/Cm";
import Mrm from "./pages/mrm/Mrm";
import Register from './pages/Register'; // 
import Logout from './pages/Logout'; // A
import ProtectedModuleRoute from './components/ProtectedModuleRoute';

import Login from "./pages/Login"; // ✅ new
import AuthWrapper from "./AuthWrapper"; // ✅ new

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/login" element={<Login />} /> {/* ✅ New public route */}

          {/* ✅ Protected routes */}
          <Route path="/" element={
              <ProtectedRoute>
              <AuthWrapper>
                <Home />
              </AuthWrapper>
              </ProtectedRoute>
            }
          />

          <Route path="/bpm" element={
  <ProtectedModuleRoute moduleName="BPM">
    <Bpm />
  </ProtectedModuleRoute>
} />


          <Route path="/bpm/*" element={<AuthWrapper><Bpm /></AuthWrapper>} />
          <Route path="/dashboard" element={<AuthWrapper><Dashboardmain /></AuthWrapper>} />
          <Route path="/sbforms" element={<AuthWrapper><Sbforms /></AuthWrapper>} />
          <Route path="/dak" element={<AuthWrapper><Dak /></AuthWrapper>} />
          <Route path="/cm" element={<AuthWrapper><Cm /></AuthWrapper>} />
          <Route path="/mrm" element={<AuthWrapper><Mrm /></AuthWrapper>} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/logout" element={<Logout />} />
          
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
