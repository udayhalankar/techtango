import { Navigate } from 'react-router-dom';

export default function ProtectedModuleRoute({ moduleName, children }) {
  const subscriptions = JSON.parse(localStorage.getItem('subscriptions'));

  const isSubscribed = subscriptions?.some(
    (s) => s.module_name === moduleName && s.status === 'active'
  );

  if (!isSubscribed) return <Navigate to="/" />;
  return children;
}
