import React from 'react';
import './SessionExpiredModal.scss';

export default function SessionExpiredModal({ onConfirm }) {
  return (
    <div className="session-modal-backdrop">
      <div className="session-modal">
        <h3>Session Expired</h3>
        <p>Your session has expired. Please log in again.</p>
        <button onClick={onConfirm}>Login</button>
      </div>
    </div>
  );
}
