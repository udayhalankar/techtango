import React from 'react'
import "./footer.scss"

const Footer = () => {
  return (
   
       <div className='footer'>
       <spam>@Techtango</spam>
       <spam> Design Origins</spam>
       </div>
    
  )
}

export default Footer