// client/src/services/api.js
import axios from 'axios';
import ReactDOM from 'react-dom';
import SessionExpiredModal from '../components/SessionExpiredModal';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (
      error.response &&
      (error.response.status === 401 || error.response.status === 403)
    ) {
      // Avoid multiple modals
      if (!document.getElementById('session-expired-modal')) {
        const container = document.createElement('div');
        container.id = 'session-expired-modal';
        document.body.appendChild(container);

        ReactDOM.render(
          <SessionExpiredModal
            onConfirm={() => {
              localStorage.removeItem('token');
              localStorage.removeItem('subscriptions');
              window.location.href = '/login';
            }}
          />,
          container
        );
      }
    }

    return Promise.reject(error);
  }
);

export default api;



// // src/services/api.js
// import axios from 'axios';

// const api = axios.create({
//   baseURL: process.env.REACT_APP_API_URL,
// });

// // Attach token to every request
// api.interceptors.request.use((config) => {
//   const token = localStorage.getItem('token');
//   if (token) {
//     config.headers.Authorization = `Bearer ${token}`;
//   }
//   return config;
// });

// // ✅ Handle token expiration globally
// api.interceptors.response.use(
//   (response) => response,
//   (error) => {
//     if (
//       error.response &&
//       (error.response.status === 401 || error.response.status === 403)
//     ) {
//       alert('⚠️ Session expired. Please log in again.');
//       localStorage.removeItem('token');
//       localStorage.removeItem('subscriptions');
//       window.location.href = '/login'; // ✅ Redirect to login
//     }
//     return Promise.reject(error);
//   }
// );

// export default api;





// // // src/services/api.js

// // import axios from 'axios';

// // const api = axios.create({
// //   baseURL: 'http://localhost:5000/api',
// //   baseURL: process.env.REACT_APP_API_URL,
// // });

// // // Attach token for protected routes
// // api.interceptors.request.use(
// //   (config) => {
// //     const token = localStorage.getItem('token'); // or sessionStorage
// //     if (token) {
// //       config.headers.Authorization = `Bearer ${token}`;
// //     }
// //     return config;
// //   },
// //   (error) => Promise.reject(error)
// // );

// // export default api;
