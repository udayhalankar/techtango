import React from 'react';
import "./cm.scss";

export const Cm = () => {
  return (
    <div>Cm</div>
  )
}

export default Cm;
