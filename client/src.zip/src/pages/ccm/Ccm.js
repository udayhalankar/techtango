import React from 'react';
import "./ccm.scss";

export const Ccm = () => {
  return (
    <div>Ccm</div>
  )
}

export default Ccm;
