// server/rmrequest/routes.js
const express = require("express");
const router = express.Router();
const svc = require("./service");
const v = require("./validators");
const db = require("../../db");

// Search (paged / filtered)
router.post("/search", async (req, res, next) => {
  try {
    const p = v.parseSearch(req.body);
    res.json(await svc.search(p));
  } catch (e) { next(e); }
});

// Create a request
router.post("/", async (req, res, next) => {
  try {
    const p = v.parseCreate(req.body);
    res.json(await svc.create(p));
  } catch (e) { next(e); }
});

// Get by id
router.get("/:id", async (req, res, next) => {
  try { res.json(await svc.getById(Number(req.params.id))); }
  catch (e) { next(e); }
});

// Patch (update a subset of fields)
router.patch("/:id", async (req, res, next) => {
  try {
    const p = v.parsePatch(req.body);
    res.json(await svc.patch(Number(req.params.id), p));
  } catch (e) { next(e); }
});

// Update only status (handy for workflows)
router.post("/:id/status", async (req, res, next) => {
  try {
    const { requestStatus } = v.parseStatusOnly(req.body);
    res.json(await svc.updateStatus(Number(req.params.id), requestStatus));
  } catch (e) { next(e); }
});

// Delete (optional)
router.delete("/:id", async (req, res, next) => {
  try { res.json(await svc.remove(Number(req.params.id))); }
  catch (e) { next(e); }
});

module.exports = router;
