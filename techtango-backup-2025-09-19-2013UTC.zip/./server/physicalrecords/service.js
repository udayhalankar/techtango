// module.exports = {
// async search({ text }) {
// // TODO: replace with DB. Returning demo rows matching your screenshot columns.
// return {
// items: [
// { id: 1, fileId: "TM-FIN-F2345", departmentFileId: "Budget 1 — 2022", boxId: "TM-FIN-B23", dateCreated: "21 July 2022", status: "IN", custodian: "RECORDS", requestType: "SERVICE", objectId: 1004, owner: "Uday Halankar", category: "Finance", period: "Jan to Mar 23", recordsManager: "Uday Halankar", recordsClassification: "Finance Records" },
// ],
// };
// },
// async submit(payload) { return { ok: true, submitted: payload?.ids?.length || 0 }; },
// async getRequest(id) { return { id, history: [] }; },
// async processService(id, body) { return { ok: true, id, type: "SERVICE" }; },
// async processMaterial(id, body) { return { ok: true, id, type: "MATERIAL" }; },
// async inwardBoxes(body) { return { ok: true }; },
// async inwardFiles(body) { return { ok: true }; },
// async register(body) { return { ok: true, id: 1234 }; },
// };


const db = require("../db");

const SELECT_COLUMNS = `
  id, tenantid, subtenantid, owner, custodian, requestid, requesttype,
  fileid, binid, fileplanname, subtenantdeptcode, subtenantcode,
  filestatus, activestorage, inactivestorage, facility, location,
  deptfileid, inwarddate, vitalstatus, rmclassification, cutoffdt,
  retentionperiodpostcutoff, classification, category, isarchive,
  otherdetails1, otherdetails2, otherdetails3, holdstatus, isrecord,
  isscancopyavailable, scancopyurl, ispotentialrecord, idcreatedate,
  date_created, created_by, date_modified, modified_by, recordlastaltered
`;

module.exports = {
  async search({ text = "" }) {
    const term = `%${text}%`;
    const { rows } = await db.query(
      `
      SELECT ${SELECT_COLUMNS}
      FROM rmfilemaster
      WHERE $1 = '%%'
         OR fileid ILIKE $1
         OR deptfileid ILIKE $1
         OR binid ILIKE $1
         OR custodian ILIKE $1
         OR requesttype ILIKE $1
         OR filestatus ILIKE $1
      ORDER BY date_created DESC, id DESC
      LIMIT 200
      `,
      [term]
    );

    const items = rows.map(r => ({
      id: r.id,
      fileId: r.fileid,
      departmentFileId: r.deptfileid,
      boxId: r.binid,
      dateCreated: r.date_created,
      status: r.filestatus,
      custodian: r.custodian,
      requestType: r.requesttype,
    }));
    return { items, total: rows.length };
  },

  async submit(payload) {
    const count = Array.isArray(payload?.ids) ? payload.ids.length : 0;
    return { ok: true, submitted: count };
  },

  async getRequest(id) {
    const { rows } = await db.query(
      `SELECT ${SELECT_COLUMNS} FROM rmfilemaster WHERE id = $1`,
      [id]
    );
    return rows[0] || null;
  },

  async processService(id, body) {
    await db.query(
      `UPDATE rmfilemaster SET modified_by = $2 WHERE id = $1`,
      [id, body?.user || "system"]
    );
    return { ok: true, id, type: "SERVICE" };
  },

  async processMaterial(id, body) {
    await db.query(
      `UPDATE rmfilemaster SET modified_by = $2 WHERE id = $1`,
      [id, body?.user || "system"]
    );
    return { ok: true, id, type: "MATERIAL" };
  },

  async inwardBoxes(body)  { return { ok: true, received: body }; },
  async inwardFiles(body)  { return { ok: true, received: body }; },

  async register(body) {
    const r = body || {};
    const { rows } = await db.query(
      `
      INSERT INTO rmfilemaster
        (tenantid, subtenantid, owner, custodian, requestid, requesttype,
         fileid, binid, fileplanname, subtenantdeptcode, subtenantcode,
         filestatus, facility, location, deptfileid, inwarddate,
         created_by, modified_by)
      VALUES
        ($1,$2,$3,$4,$5,$6,
         $7,$8,$9,$10,$11,
         $12,$13,$14,$15,$16,
         $17,$18)
      RETURNING id
      `,
      [
        r.tenantId ?? null,
        r.subTenantId ?? null,
        r.owner ?? null,
        r.custodian ?? null,
        r.requestId ?? null,
        r.requestType ?? null,
        r.fileId,
        r.binId ?? null,
        r.fileplanName ?? null,
        r.subTenantDeptcode ?? null,
        r.subTenantcode ?? null,
        r.fileStatus ?? "IN",
        r.facility ?? null,
        r.location ?? null,
        r.deptFileId,
        r.inwardDate ?? new Date(),
        r.created_By ?? "system",
        r.modified_By ?? "system",
      ]
    );
    return { ok: true, id: rows[0].id };
  },
};
