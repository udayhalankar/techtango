import React from 'react';
import "./rms.scss";
import ListTodos from '../../components/ListTodos';
import InputTodo from '../../components/InputTodo';
import Navbar  from '../../components/navbar/Navbar';
import Footer from '../../components/footer/Footer';

import ChartBox from '../../components/chartBox/ChartBox';
import Topbox from '../../components/topbox/Topbox';
import { AiOutlineDiff } from "react-icons/ai";
import { Link } from "react-router-dom";
import RmsMenu from '../../components/rmsMenu/RmsMenu';


export const Rms = () => {
  return (
<div>
{/* <Layout />   */}

RMS 
</div>
   
    
  )
}

export default Rms;