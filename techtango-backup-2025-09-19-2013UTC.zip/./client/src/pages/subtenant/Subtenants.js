import React from 'react'

export const Subtenants = () => {
  return (
    <div>Subtenants</div>
  )
}
