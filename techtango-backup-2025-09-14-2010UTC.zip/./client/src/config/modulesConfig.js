// src/config/modulesConfig.js

import Bpm from "../pages/bpm/Bpm";
import Dashboardmain from "../pages/dashboardmain/Dashboardmain";
import Sbforms from "../pages/sbforms/Sbforms";
import Dak from "../pages/dak/Dak";
import Cm from "../pages/cm/Cm";
import Ccm from "../pages/ccm/Ccm";
import Mrm from "../pages/mrm/Mrm";
import Dms from "../pages/dms/Dms";
import Approvals from "../pages/approvals/Approvals";
import Feedback from "../pages/feedback/Feedback";
import NewEnquiryForm from "../pages/enquiries/NewEnquiryForm";
import Rms from "../pages/rms/Rms";
import WorkflowManager from "../pages/workflows/WorkflowManager";
import CreateWorkflowModal from "../pages/workflows/CreateWorkflowModal";
import Enquiries from "../pages/enquiries/Enquiries";
import BulkUploader from "../components/BulkUploader";
import ListFormViews from "../components/ListFormViews"
import ChowkidarDashboard from "../pages/ChowkidarDashboard";
import UICreator from "../components/UiCreator";
import HomeLayout from "../layout/HomeLayout";
import TableCreator from "../components/TableCreator";
import ChartBuilder from "../components/ChartBuilder";
import DBSettings from "../pages/admin/DatabaseSettings";
import AdminPanel from "../pages/admin/AdminPanel";
import DBSchema from "../pages/DbSchemaExplorer";
import Workflows from "../pages/workflows/WorkflowAssignments";
import Workflowdesigner from "../pages/workflows/WorkflowDesigner";
import Workflowlibrary from "../pages/workflows/WorkflowLibrary";
import Workflowmanager from "../pages/workflows/WorkflowManager";
import FormRunner from '../pages/workflows/FormRunner';

// You can add unprotected modules by setting protected: false
const modulesConfig = {
  ChowkidarDashboard: { path: "/chowkidar", component:  ChowkidarDashboard, protected: false }, // ✅ unprotected
  BPM: { path: "/bpm/*", component: Bpm, protected: true },
  Dashboard: { path: "/dashboard", component: Dashboardmain, protected: true },
  SmartForms: { path: "/sbforms", component: Sbforms, protected: true },
  DAK: { path: "/dak", component: Dak, protected: true },
  CM: { path: "/cm", component: Cm, protected: true },
  CCM: { path: "/ccm", component: Ccm, protected: true },
  MRM: { path: "/mrm", component: Mrm, protected: true },
  DMS: { path: "/dms", component: Dms, protected: true }, 
  RMS: { path: "/Rms", component: Rms, protected: true }, 
  Approvals: { path: "/approvals", component: Approvals, protected: true }, 
  Feedback: { path: "/feedback", component: Feedback, protected: false }, // ✅ unprotected
  WorkflowManager: { path: "/workflowmanager", component: WorkflowManager, protected: false }, // ✅ unprotected
  CreateWorkflowModal: { path: "/wfmod", component: CreateWorkflowModal, protected: false }, // ✅ unprotected
  HomeLayout: { path: "/homelayout", component: HomeLayout, protected: false }, // ✅ unprotected
  TableCreator: { path: "/tables", component: TableCreator, protected: false }, // ✅ unprotected
  ChartBuilder: { path: "/charts/new", component: ChartBuilder, protected: false }, // ✅ unprotected
  // Enquiries: { path: "/enquiries", component: Enquiries, protected: false}, // ✅ unprotected
  DBSettings: { path: "/dbsettings", component: DBSettings, protected: false }, // ✅ unprotected
  AdminPanel: { path: "/adminpanel", component: AdminPanel, protected: false }, // ✅ unprotected
  DBSchema: { path: "/db-schema", component: DBSchema, protected: false }, // ✅ unprotected
  Workflows: { path: "/wfassignments", component: Workflows, protected: false }, // ✅ unprotected
  Workflowdesigner: { path: "/wfdesigner", component: Workflowdesigner, protected: false }, // ✅ unprotected
  WorkflowdesignerEdit:  { path: "/wfdesigner/:id", component: Workflowdesigner, protected: false },
  WorkflowdesignerCompat:     { path: "/workflow-designer", component: Workflowdesigner, protected: false },
  WorkflowdesignerCompatEdit: { path: "/workflow-designer/:id", component: Workflowdesigner, protected: false },
  Workflowlibrary: { path: "/wflibrary", component: Workflowlibrary, protected: false }, // ✅ unprotected
  Workflowmanager: { path: "/wfmanager", component: Workflowmanager, protected: false }, // ✅ unprotected
  //UICreator: { path: "/uicreator", component: UICreator, protected: false }, // ✅ unprotected
  FormRunner: { path: "/form/:id", component: FormRunner, protected: false }, // ✅ unprotected




  Enquiries: {
    path: '/enquiry',
    component: Enquiries,
    protected: true,
    moduleId: 12,            // ← use the numeric id
    moduleName: 'Enquiries', // optional fallback
  },
  UICreator: {
    path: '/uicreator',
    component: UICreator,
    protected: true,
    moduleId: 13,            // ← use the numeric id
    moduleName: 'UICreator', // optional fallback
  }, 
  BulkUploader: { path: "/bulkuploader", component: BulkUploader, protected: false }, // ✅ unprotected
  ListFormViews: { path: "/forms", component:  ListFormViews, protected: false }, // ✅ unprotected
 
  
 
  //NewEnquiryForm: { path: "/enquiry", component: NewEnquiryForm, protected: false }, // ✅ unprotected
};

export default modulesConfig;
