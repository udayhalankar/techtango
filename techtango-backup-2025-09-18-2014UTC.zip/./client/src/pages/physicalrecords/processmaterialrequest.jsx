import React from "react";
import { Box, Button, Stack, TextField, Typography } from "@mui/material";


export default function ProcessMaterialRequest({ row, onClose }){
return (
<Box>
<Typography variant="h6" gutterBottom>Process Material Request</Typography>
<Stack spacing={2}>
<TextField label="Material Notes" multiline minRows={3} fullWidth />
<Button variant="contained" onClick={onClose}>Submit</Button>
</Stack>
</Box>
);
}