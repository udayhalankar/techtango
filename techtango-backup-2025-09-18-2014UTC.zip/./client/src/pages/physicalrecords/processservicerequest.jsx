import React from "react";
import { Box, Button, Stack, TextField, Typography } from "@mui/material";


export default function ProcessServiceRequest({ row, onClose }){
return (
<Box>
<Typography variant="h6" gutterBottom>Process Service Request</Typography>
<Stack spacing={2}>
<TextField label="Service Notes" multiline minRows={3} fullWidth />
<Button variant="contained" onClick={onClose}>Submit</Button>
</Stack>
</Box>
);
}