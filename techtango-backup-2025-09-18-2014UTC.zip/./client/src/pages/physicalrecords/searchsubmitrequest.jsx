import React, {useState} from "react";

import {
  Box, Button, Card, CardContent, Chip, Grid, List, ListItemButton, ListItemText,
  Stack, Table, TableBody, TableCell,  MenuItem, TableHead, TableRow, TextField, Typography,
  InputAdornment, Pagination
} from "@mui/material";
import { Checkbox } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import LeftMenu from "../../components/LeftMenu";
import FileDetailsModal from "../physicalrecords/FileDetailsModal";

const NAVBAR_H = 66;     // <-- set to your AppBar height
const SIDENAV_W = 232;   // <-- keep in sync with LeftMenu width

// row height tuning (feel free to tweak)
const ROW_PY = 0.4;     // vertical padding (theme spacing units) ~3px
const CELL_PX = 1;      // horizontal padding ~8px
const HEADER_PY = 0.6;  // header vertical padding ~5px

// put these near your other layout constants
const TITLE_TOP_SPACE = 0;     // ~10px (theme.spacing)
const ALIGN_WITH_FIELDS = 1;       // ~8px left inset so grid aligns with text fields




// --- SAMPLE DATA (static) ---
const rows = [
  { id: 1, fileId: "TM-FIN-F2345", deptFileId: "Budget 1 — 2022", boxId: "TM-FIN-B23", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
  { id: 2, fileId: "TM-FIN-F2346", deptFileId: "Budget 2 — 2022", boxId: "TM-FIN-B24", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 3, fileId: "TM-FIN-F2347", deptFileId: "Budget 3 — 2022", boxId: "TM-FIN-B25", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 4, fileId: "TM-FIN-F2348", deptFileId: "Budget 4 — 2022", boxId: "TM-FIN-B26", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 5, fileId: "TM-FIN-F2349", deptFileId: "Budget 5 — 2022", boxId: "TM-FIN-B27", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 6, fileId: "TM-FIN-F2350", deptFileId: "Budget 6 — 2022", boxId: "TM-FIN-B28", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
  { id: 7, fileId: "TM-FIN-F2351", deptFileId: "Budget 7 — 2022", boxId: "TM-FIN-B29", date: "21 July 2022", status: "OUT",         custodian: "UDAY HALANKAR" },
  { id: 8, fileId: "TM-FIN-F2352", deptFileId: "Budget 8 — 2022", boxId: "TM-FIN-B30", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
  { id: 9, fileId: "TM-FIN-F2353", deptFileId: "Budget 9 — 2022", boxId: "TM-FIN-B31", date: "21 July 2022", status: "OUT",         custodian: "UDAY HALANKAR" },
  { id:10, fileId: "TM-FIN-F2354", deptFileId: "Budget 10 — 2022",boxId: "TM-FIN-B32", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
];

const StatusChip = ({ value }) => {
  const color = value === "IN" ? "success" : value === "OUT" ? "error" : "warning";
  return <Chip size="small" label={value} color={color} variant="outlined" />;
};



export default function SearchSubmitRequest() {

const [selected, setSelected] = useState([]); // array of row ids
const selectableIds = rows.filter(r => r.status === "IN").map(r => r.id);
const rowCount = selectableIds.length;

const [open, setOpen] = useState(false);
const [activeDetails, setActiveDetails] = useState(null);

const isSelected = (id) => selected.includes(id);

const [detailsOpen, setDetailsOpen] = useState(false);
const [detailsData, setDetailsData] = useState(null);

// Optional: control order/labels shown on the left
const detailsFieldOrder = [
  ["department", "Department"],
  ["boxId", "Box ID"],
  ["fileId", "File ID"],
  ["deptFileId", "Department File ID"],
  ["date", "Date Created"],
  // ["requestType", "Request Type"],
];

const handleSelectAll = (e) => {
   setSelected(e.target.checked ? selectableIds : []);
};

const handleRowCheckbox = (id) => (e) => {
    setSelected((prev) =>
      e.target.checked ? [...prev, id] : prev.filter((x) => x !== id)
    );
  };

  return (
    <Box sx={{ display: "flex" }}>
      {/* LEFT MENU: NO TOP BORDER; BELOW NAVBAR */}
      
      <LeftMenu width={SIDENAV_W} offsetTop={NAVBAR_H}>
        <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
          My Assignments
        </Typography>
        <List dense>
          <ListItemButton><ListItemText primary="RWM" /></ListItemButton>
          <ListItemButton><ListItemText primary="ECM" /></ListItemButton>
        </List>

        <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2, mb: 1 }}>
          Recently Visited
        </Typography>
        <List dense>
          {[
            "Delayed Request","New Invoices","Storage Utilization Report","Destruction Approval",
            "Vital Documents Report","Recent Searches","Saved Searches",
          ].map((t) => (<ListItemButton key={t}><ListItemText primary={t} /></ListItemButton>))}
        </List>

        <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2, mb: 1 }}>
          Filter Results
        </Typography>
        <Box sx={{ bgcolor: "#f6f7fb", border: "1px solid #e0e4ee", borderRadius: 1, mb: 1.5 }}>
          <Box sx={{ px: 1.25, py: .75, bgcolor: "#2f2b40", color: "white", borderTopLeftRadius: 4, borderTopRightRadius: 4 }}>
            <Typography variant="caption">Categories</Typography>
          </Box>
          <Box sx={{ p: 1.25, fontSize: 12 }}>
            <Stack direction="row" justifyContent="space-between" sx={{ py: .25 }}><span>Cat1</span><span>25</span></Stack>
            <Stack direction="row" justifyContent="space-between" sx={{ py: .25 }}><span>Cat2</span><span>89</span></Stack>
            <Stack direction="row" justifyContent="space-between" sx={{ py: .25 }}><span>Cat3</span><span>55</span></Stack>
          </Box>
        </Box>
        {/* (Date Created / Type blocks… same pattern if you want to keep them) */}
      </LeftMenu>

      {/* MAIN CONTENT — starts right under navbar, no extra top gap */}
      <Box
        id="pr-main"
        sx={{
          position: "fixed",
          top: NAVBAR_H,       // sits right under your navbar
          left: SIDENAV_W,     // sits to the right of the LeftMenu
          right: 0,
          bottom: 0,           // fills to bottom
          overflowY: "auto",   // <-- only this scrolls
          p: 2,                // page padding
        }}
      >
        {/* Request: single-column; compact */}
        {/* <Card variant="outlined" sx={{ mb: 1.25 }}> */}
          <CardContent sx={{ p: 1, pt: 0.5 }}>
            <Grid container alignItems="center" spacing={0}>
              <Grid item xs>
                 <Typography
          variant="h6"
          sx={{ color: "#f0772c", mt: TITLE_TOP_SPACE, mb: 0.75, fontSize: 22, ml: ALIGN_WITH_FIELDS }}
        >
          Search & Submit File Request
        </Typography>
                <Stack spacing={0.75} sx={{ maxWidth: 320 }}>
                  {/* <TextField size="small" margin="dense" label="Requester ID" fullWidth />
                  <TextField size="small" margin="dense" label="Requester Name" fullWidth /> */}
                  <TextField size="small" margin="dense" label="Request Category" fullWidth />
                  <TextField
                    select                     // 👈 makes it a dropdown
                    size="small"
                    margin="dense"
                    label="Request Type"
                    fullWidth
                    defaultValue=""            // optional: sets empty by default
                  >
                    <MenuItem value="">Select Request Type</MenuItem>
                    <MenuItem value="Retrieval">Retrieval</MenuItem>
                    <MenuItem value="Refiling">Refiling</MenuItem>
                    <MenuItem value="Audit">Audit</MenuItem>
                    <MenuItem value="Insertion">Insertion</MenuItem>
                    <MenuItem value="Permout Delivery">Permout Delivery</MenuItem>
                    <MenuItem value="Permout Destruction">Permout Destruction</MenuItem>
                  </TextField>
                  <Grid item>
                <TextField
                  size="small"
                  margin="dense"
                  placeholder="Search"
                  sx={{ width: 320 }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon fontSize="small" />
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>
                </Stack>
              </Grid>

              {/* Search aligned right */}
              <Grid item>
                {/* <TextField
                  size="small"
                  margin="dense"
                  placeholder="Search"
                  sx={{ width: 320 }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon fontSize="small" />
                      </InputAdornment>
                    ),
                  }}
                /> */}
              </Grid>
            </Grid>
          </CardContent>

        {/* </Card> */}

        {/* Section title */}
        {/* <Typography
          variant="h6"
          sx={{ color: "#f0772c", mt: TITLE_TOP_SPACE, mb: 0.75, fontSize: 18, ml: ALIGN_WITH_FIELDS }}
        >
          Search & Submit File Request
        </Typography> */}

        

        {/* Grid with dark header for contrast */}
        <Card variant="outlined" sx={{ ml: ALIGN_WITH_FIELDS }}>
          <CardContent sx={{ p: 0 }}>
            {/* <Table size="small" stickyHeader> */}
            <Table size="small" stickyHeader
                sx={{
                  // header cells
                  "& thead .MuiTableCell-root": {
                    py: HEADER_PY,
                    px: CELL_PX,
                    lineHeight: 2,
                  },
                  // body cells
                  "& tbody .MuiTableCell-root": {
                    py: ROW_PY,
                    px: CELL_PX,
                    lineHeight: 1.2,
                  },
                }}
              >
              <TableHead sx={{ bgcolor: "#554d78" }}>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    size="small"
                    indeterminate={selected.length > 0 && selected.length < rowCount}
                    checked={rowCount > 0 && selected.length === rowCount}
                    onChange={handleSelectAll}
                    inputProps={{ "aria-label": "Select all rows" }}
                  />
                </TableCell>

                <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>File ID</TableCell>
                <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>Department File ID</TableCell>
                <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>Box ID</TableCell>
                <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>Date Created</TableCell>
                <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>Status</TableCell>
                <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>Custodian</TableCell>
                <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>Soft Copy</TableCell>
                {/* <TableCell sx={{ color: "grey", fontSize: 12, fontWeight: 600 }}>Soft Copy</TableCell> */}
              </TableRow>
            </TableHead>
              <TableBody>
  {rows.map((r) => {
    const checked = isSelected(r.id);
    return (
      <TableRow
        key={r.id}
        hover
        role="checkbox"
        aria-checked={checked}
        selected={checked}
      >
        <TableCell padding="checkbox">
          <Checkbox
            size="small"
            checked={checked}
            onChange={handleRowCheckbox(r.id)}
            disabled={r.status !== "IN"}         // ← disable unless IN
            inputProps={{ "aria-label": `Select ${r.fileId}` }}
          />
        </TableCell>

        <TableCell sx={{ fontWeight: 600, fontSize: 13 }}>{r.fileId}</TableCell>
        <TableCell sx={{ fontSize: 13 }}>{r.deptFileId}</TableCell>
        <TableCell sx={{ fontSize: 13 }}>{r.boxId}</TableCell>
        <TableCell sx={{ fontSize: 13 }}>{r.date}</TableCell>
        <TableCell sx={{ fontSize: 13 }}><StatusChip value={r.status} /></TableCell>
        <TableCell sx={{ fontSize: 13 }}>{r.custodian}</TableCell>
        <TableCell>
          <Button
              size="small"
              variant="contained"
              sx={{ minWidth: 70, py: 0.3, fontSize: 12 }}
              onClick={() => {
                // Build a details object from the row (plus any extras you want)
                const details = {
                  // use row values; add fallbacks if some keys aren't present
                  department: r.department ?? "Finance",
                  boxId: r.boxId,
                  fileId: r.fileId,
                  deptFileId: r.deptFileId,
                  date: r.date,
                  requestType: r.requestType ?? "",      // wire this to your Request Type state if you have one
                  softcopy: r.softcopy ?? "Budget 2022 documents.PDF",
                  // keep original row too if you want:
                  // ...r,
                };
                setDetailsData(details);
                setDetailsOpen(true);
              }}
            >
              Open
            </Button>

        <FileDetailsModal
          open={detailsOpen}
          onClose={() => setDetailsOpen(false)}
          details={detailsData}
          fieldOrder={detailsFieldOrder}
        />
        </TableCell>
        <TableCell>
        {/* <Button size="small" variant="contained" color="secondary" sx={{ minWidth: 86, py: 0.3, fontSize: 12 }}>View</Button> */}
        </TableCell>
      </TableRow>
    );
  })}
</TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Footer actions */}
        <Grid container alignItems="center" sx={{ mt: 1 }}>
          <Grid item xs>
            <Button variant="contained" size="small">Submit Request</Button>
          </Grid>
          <Grid item>
            <Pagination count={7} page={2} size="small" />
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
}
