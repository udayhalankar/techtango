import React from 'react'

export const Subtenantadd = () => {
  return (
    <div>Subtenantadd</div>
  )
}

export default Subtenantadd;