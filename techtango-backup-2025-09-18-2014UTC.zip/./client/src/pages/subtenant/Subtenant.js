import React from 'react'

export const Subtenant = () => {
  return (
    <div>Subtenant</div>
  )
}
