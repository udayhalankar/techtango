import React from 'react'

export const Tenant = () => {
  return (
    <div>Tenant</div>
  )
}

export default Tenant;