import React from "react";
import {
  Box, Button, Card, CardContent, Chip, Grid, List, ListItemButton, ListItemText,
  Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography,
  InputAdornment, Pagination
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import LeftMenu from "../../components/LeftMenu";

const NAVBAR_H = 66;     // <-- set to your AppBar height
const SIDENAV_W = 232;   // <-- keep in sync with LeftMenu width

// --- SAMPLE DATA (static) ---
const rows = [
  { id: 1, fileId: "TM-FIN-F2345", deptFileId: "Budget 1 — 2022", boxId: "TM-FIN-B23", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
  { id: 2, fileId: "TM-FIN-F2346", deptFileId: "Budget 2 — 2022", boxId: "TM-FIN-B24", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 3, fileId: "TM-FIN-F2347", deptFileId: "Budget 3 — 2022", boxId: "TM-FIN-B25", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 4, fileId: "TM-FIN-F2348", deptFileId: "Budget 4 — 2022", boxId: "TM-FIN-B26", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 5, fileId: "TM-FIN-F2349", deptFileId: "Budget 5 — 2022", boxId: "TM-FIN-B27", date: "21 July 2022", status: "CIRCULATION", custodian: "MUKESH KUMAR" },
  { id: 6, fileId: "TM-FIN-F2350", deptFileId: "Budget 6 — 2022", boxId: "TM-FIN-B28", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
  { id: 7, fileId: "TM-FIN-F2351", deptFileId: "Budget 7 — 2022", boxId: "TM-FIN-B29", date: "21 July 2022", status: "OUT",         custodian: "UDAY HALANKAR" },
  { id: 8, fileId: "TM-FIN-F2352", deptFileId: "Budget 8 — 2022", boxId: "TM-FIN-B30", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
  { id: 9, fileId: "TM-FIN-F2353", deptFileId: "Budget 9 — 2022", boxId: "TM-FIN-B31", date: "21 July 2022", status: "OUT",         custodian: "UDAY HALANKAR" },
  { id:10, fileId: "TM-FIN-F2354", deptFileId: "Budget 10 — 2022",boxId: "TM-FIN-B32", date: "21 July 2022", status: "IN",          custodian: "RECORDS" },
];

const StatusChip = ({ value }) => {
  const color = value === "IN" ? "success" : value === "OUT" ? "error" : "warning";
  return <Chip size="small" label={value} color={color} variant="outlined" />;
};

export default function SearchSubmitRequest() {
  return (
    <Box sx={{ display: "flex" }}>
      {/* LEFT MENU: NO TOP BORDER; BELOW NAVBAR */}
      <LeftMenu width={SIDENAV_W} offsetTop={NAVBAR_H}>
        <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
          My Assignments
        </Typography>
        <List dense>
          <ListItemButton><ListItemText primary="RWM" /></ListItemButton>
          <ListItemButton><ListItemText primary="ECM" /></ListItemButton>
        </List>

        <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2, mb: 1 }}>
          Recently Visited
        </Typography>
        <List dense>
          {[
            "Delayed Request","New Invoices","Storage Utilization Report","Destruction Approval",
            "Vital Documents Report","Recent Searches","Saved Searches",
          ].map((t) => (<ListItemButton key={t}><ListItemText primary={t} /></ListItemButton>))}
        </List>

        <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2, mb: 1 }}>
          Filter Results
        </Typography>
        <Box sx={{ bgcolor: "#f6f7fb", border: "1px solid #e0e4ee", borderRadius: 1, mb: 1.5 }}>
          <Box sx={{ px: 1.25, py: .75, bgcolor: "#2f2b40", color: "white", borderTopLeftRadius: 4, borderTopRightRadius: 4 }}>
            <Typography variant="caption">Categories</Typography>
          </Box>
          <Box sx={{ p: 1.25, fontSize: 12 }}>
            <Stack direction="row" justifyContent="space-between" sx={{ py: .25 }}><span>Cat1</span><span>25</span></Stack>
            <Stack direction="row" justifyContent="space-between" sx={{ py: .25 }}><span>Cat2</span><span>89</span></Stack>
            <Stack direction="row" justifyContent="space-between" sx={{ py: .25 }}><span>Cat3</span><span>55</span></Stack>
          </Box>
        </Box>
        {/* (Date Created / Type blocks… same pattern if you want to keep them) */}
      </LeftMenu>

      {/* MAIN CONTENT — starts right under navbar, no extra top gap */}
      <Box
        component="main"
        sx={{
          flex: 1,
          ml: `${SIDENAV_W}px`,   // room for the drawer
          mt: `${NAVBAR_H}px`,    // sits directly under navbar (no blue gap)
          px: 2,
          pb: 2,
        }}
      >
        {/* Request: single-column; compact */}
        {/* <Card variant="outlined" sx={{ mb: 1.25 }}> */}
          <CardContent sx={{ p: 1 }}>
            <Grid container alignItems="center" spacing={1}>
              <Grid item xs>
                <Typography variant="h6" sx={{ mb: 1, fontSize: 18 }}>Request</Typography>
                <Stack spacing={1} sx={{ maxWidth: 560 }}>
                  <TextField size="small" label="Requester ID" fullWidth />
                  <TextField size="small" label="Requester Name" fullWidth />
                  <TextField size="small" label="Request Category" fullWidth />
                  <TextField size="small" label="Request Type" placeholder="Retrieval, Refiling, Audit…" fullWidth />
                </Stack>
              </Grid>
              {/* Search aligned to the right of Request block */}
              <Grid item>
                <TextField
                  size="small"
                  placeholder="Search"
                  sx={{ width: 360 }}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon fontSize="small" />
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>
            </Grid>
          </CardContent>
        {/* </Card> */}

        {/* Section title */}
        <Typography variant="h6" sx={{ color: "#f0772c", mb: 0.75, fontSize: 18 }}>
          Search & Submit File Request
        </Typography>

        {/* Grid with dark header for contrast */}
        <Card variant="outlined">
          <CardContent sx={{ p: 0 }}>
            <Table size="small" stickyHeader>
              <TableHead sx={{ bgcolor: "#252233" }}>
                <TableRow>
                  {[
                    "File ID","Department File ID","Box ID","Date Created",
                    "Status","Custodian","View Details","Process Request",
                  ].map((h) => (
                    <TableCell key={h} sx={{ color: "white", fontSize: 12, fontWeight: 600 }}>
                      {h}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id} hover>
                    <TableCell sx={{ fontWeight: 600, fontSize: 13 }}>{r.fileId}</TableCell>
                    <TableCell sx={{ fontSize: 13 }}>{r.deptFileId}</TableCell>
                    <TableCell sx={{ fontSize: 13 }}>{r.boxId}</TableCell>
                    <TableCell sx={{ fontSize: 13 }}>{r.date}</TableCell>
                    <TableCell sx={{ fontSize: 13 }}><StatusChip value={r.status} /></TableCell>
                    <TableCell sx={{ fontSize: 13 }}>{r.custodian}</TableCell>
                    <TableCell>
                      <Button size="small" variant="contained" sx={{ minWidth: 70, py: 0.3, fontSize: 12 }}>DETAILS</Button>
                    </TableCell>
                    <TableCell>
                      <Button size="small" variant="contained" color="secondary" sx={{ minWidth: 86, py: 0.3, fontSize: 12 }}>PROCESS</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Footer actions */}
        <Grid container alignItems="center" sx={{ mt: 1 }}>
          <Grid item xs>
            <Button variant="contained" size="small">Submit Request</Button>
          </Grid>
          <Grid item>
            <Pagination count={7} page={2} size="small" />
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
}
