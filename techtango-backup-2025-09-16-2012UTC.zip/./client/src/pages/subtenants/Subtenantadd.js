import React from 'react'

export const Subtenantadd = () => {
  return (
    <div>Addtenant</div>
  )
}

export default Subtenantadd;
