import React from 'react';
import "./dak.scss";

export const Dak = () => {
  return (
    <div>Dak</div>
  )
}

export default Dak;