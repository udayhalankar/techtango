import React from 'react';
import "./cm.scss";

export const Cm = () => {
  return (
    <div>Case Management</div>
  )
}

export default Cm;
