// server/routes/workflows/assignmentswf.js
const express = require('express');
const router = express.Router();

const pool = require('../../db');
const { verifyToken } = require('../../middleware/authMiddleware');

// 🔒 Require a valid JWT for everything in here
router.use(verifyToken);

// ---- tiny query helper (with logging on error)
async function q(text, params = []) {
  try { return await pool.query(text, params); }
  catch (err) {
    console.error('PG ERROR:\nSQL:\n', text, '\nPARAMS:', params, '\nERR:', err);
    throw err;
  }
}

// ---- metadata helpers (cache simple checks)
const tblCache = new Map();
const colCache = new Map();

async function tableExists(name) {
  if (tblCache.has(name)) return tblCache.get(name);
  const sql = `
    SELECT 1 
    FROM information_schema.tables 
    WHERE table_schema='public' AND table_name=$1 LIMIT 1
  `;
  const ok = !!(await q(sql, [name])).rowCount;
  tblCache.set(name, ok);
  return ok;
}
async function colExists(table, col) {
  const key = `${table}|${col}`;
  if (colCache.has(key)) return colCache.get(key);
  const sql = `
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_schema='public' AND table_name=$1 AND column_name=$2 LIMIT 1
  `;
  const ok = !!(await q(sql, [table, col])).rowCount;
  colCache.set(key, ok);
  return ok;
}
async function firstExistingCol(table, candidates) {
  for (const c of candidates) if (await colExists(table, c)) return c;
  return null;
}

/* ---------------------------------------------
 * INBOX  (tasks assigned to the logged-in user)
 * --------------------------------------------- */
async function queryInbox(userId) {
  if (!(await tableExists('workflow_tasks')) || !(await tableExists('workflow_instances'))) {
    throw new Error('Required tables (workflow_tasks/workflow_instances) not found');
  }

  const assigneeCol     = (await firstExistingCol('workflow_tasks', ['assignee_id','assigned_to','assignee'])) || 'assignee_id';
  const taskStatusCol   = await firstExistingCol('workflow_tasks', ['status','task_status']);
  const taskFormIdCol   = (await colExists('workflow_tasks', 'form_id')) ? 'form_id' : null;
  const taskNodeIdCol   = (await colExists('workflow_tasks', 'node_id')) ? 'node_id' : null;
  const taskNodeTypeCol = await firstExistingCol('workflow_tasks', ['node_type','type']);

  const instStatusCol   = await firstExistingCol('workflow_instances', ['status','instance_status']);
  const instStartedCol  = (await colExists('workflow_instances','started_at')) ? 'started_at'
                          : (await colExists('workflow_instances','created_at')) ? 'created_at' : null;
  const masterRowIdCol  = (await colExists('workflow_instances','master_row_id')) ? 'master_row_id'
                          : (await colExists('workflow_instances','record_id')) ? 'record_id' : null;

  const haveWorkflows   = await tableExists('workflows');
  const wfNameExpr      = haveWorkflows && (await colExists('workflows','name')) ? 'w.name' : `'Workflow'`;

  const selectParts = [
    't.id AS task_id',
    't.instance_id',
    taskNodeIdCol     ? `t.${taskNodeIdCol} AS node_id`       : `NULL::text  AS node_id`,
    taskNodeTypeCol   ? `t.${taskNodeTypeCol} AS node_type`   : `NULL::text  AS node_type`,
    taskFormIdCol     ? `t.${taskFormIdCol} AS form_id`       : `NULL::int   AS form_id`,
    instStatusCol     ? `i.${instStatusCol} AS instance_status` : `NULL::text AS instance_status`,
    masterRowIdCol    ? `i.${masterRowIdCol} AS record_id`    : `NULL::int   AS record_id`,
    `${wfNameExpr} AS workflow_name`,
  ];

  // started_at: avoid COALESCE type-mismatch by selecting one branch in JS
  const startedExpr = instStartedCol ? `i.${instStartedCol}` : `NOW()`;
  selectParts.push(`${startedExpr} AS started_at`);

  const joins = [
    'JOIN workflow_instances i ON i.id = t.instance_id',
    ...(haveWorkflows ? ['LEFT JOIN workflows w ON w.id = i.workflow_id'] : []),
  ];

  const where = [
    `t.${assigneeCol} = $1`,
    ...(taskStatusCol ? [`(t.${taskStatusCol} IS NULL OR t.${taskStatusCol} IN ('NEW','PENDING','ASSIGNED','OPEN','IN_PROGRESS'))`] : []),
  ];

  const orderBy = instStartedCol ? `i.${instStartedCol}` : 't.id';

  const sql = `
    SELECT ${selectParts.join(', ')}
    FROM workflow_tasks t
    ${joins.join('\n')}
    WHERE ${where.join(' AND ')}
    ORDER BY ${orderBy} DESC
    LIMIT 200
  `;

  const { rows } = await q(sql, [userId]);
  return rows;
}

/* ---------------------------------------------
 * OUTBOX (instances started by the logged-in user)
 * --------------------------------------------- */
async function queryOutbox(userId) {
  if (!(await tableExists('workflow_instances'))) {
    throw new Error('Required table workflow_instances not found');
  }

  const startedByCol   = await firstExistingCol('workflow_instances', ['started_by','created_by','owner_id','user_id']);
  const instStatusCol  = await firstExistingCol('workflow_instances', ['status','instance_status']);
  const instStartedCol = (await colExists('workflow_instances','started_at')) ? 'started_at'
                        : (await colExists('workflow_instances','created_at')) ? 'created_at' : null;
  const masterRowCol   = (await colExists('workflow_instances','master_row_id')) ? 'master_row_id'
                        : (await colExists('workflow_instances','record_id')) ? 'record_id' : null;

  const haveWorkflows  = await tableExists('workflows');
  const wfNameExpr     = haveWorkflows && (await colExists('workflows','name')) ? 'w.name' : `'Workflow'`;

  if (!startedByCol) {
    // hard fail if we cannot scope to the current user
    throw new Error('workflow_instances has no started_by/created_by/owner_id/user_id column to scope by user');
  }

  const selectParts = [
    'i.id AS instance_id',
    instStatusCol  ? `i.${instStatusCol} AS instance_status` : `NULL::text AS instance_status`,
    masterRowCol   ? `i.${masterRowCol} AS master_row_id`    : `NULL::int  AS master_row_id`,
    `${wfNameExpr} AS workflow_name`,
  ];
  const startedExpr = instStartedCol ? `i.${instStartedCol}` : `NOW()`;
  selectParts.push(`${startedExpr} AS started_at`);

  const joins = [
    ...(haveWorkflows ? ['LEFT JOIN workflows w ON w.id = i.workflow_id'] : []),
  ];

  const orderBy = instStartedCol ? `i.${instStartedCol}` : 'i.id';

  const sql = `
    SELECT ${selectParts.join(', ')}
    FROM workflow_instances i
    ${joins.join('\n')}
    WHERE i.${startedByCol} = $1
    ORDER BY ${orderBy} DESC
    LIMIT 200
  `;

  const { rows } = await q(sql, [userId]);
  return rows;
}

/* -------------- Routes -------------- */

router.get('/inbox', async (req, res) => {
  try {
    const userId = req.user?.userId || req.user?.id;
    if (!userId) return res.status(400).json({ error: 'Missing user id' });
    res.json(await queryInbox(userId));
  } catch (err) {
    console.error('GET /inbox error:', err);
    res.status(500).json({ error: 'Failed to fetch inbox' });
  }
});

router.get('/outbox', async (req, res) => {
  try {
    const userId = req.user?.userId || req.user?.id;
    if (!userId) return res.status(400).json({ error: 'Missing user id' });
    res.json(await queryOutbox(userId));
  } catch (err) {
    console.error('GET /outbox error:', err);
    res.status(500).json({ error: 'Failed to fetch outbox' });
  }
});

// Optional namespaced aliases
router.get('/workflows/assignments/inbox', async (req, res) => {
  try {
    const userId = req.user?.userId || req.user?.id;
    if (!userId) return res.status(400).json({ error: 'Missing user id' });
    res.json(await queryInbox(userId));
  } catch (err) {
    console.error('GET /workflows/assignments/inbox error:', err);
    res.status(500).json({ error: 'Failed to fetch inbox' });
  }
});

router.get('/workflows/assignments/outbox', async (req, res) => {
  try {
    const userId = req.user?.userId || req.user?.id;
    if (!userId) return res.status(400).json({ error: 'Missing user id' });
    res.json(await queryOutbox(userId));
  } catch (err) {
    console.error('GET /workflows/assignments/outbox error:', err);
    res.status(500).json({ error: 'Failed to fetch outbox' });
  }
});

module.exports = router;
