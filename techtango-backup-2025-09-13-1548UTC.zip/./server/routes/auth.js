require('dotenv').config();
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const nodemailer = require('nodemailer');
const { OAuth2Client } = require('google-auth-library');
const { logAudit } = require('../utils/auditLogger');


const {
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  GOOGLE_REDIRECT_URI,
  JWT_SECRET = 'YOUR_SECRET_KEY',
} = process.env;

const client = new OAuth2Client(
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  GOOGLE_REDIRECT_URI
);

router.use(express.json());

/** REGISTER **/
router.post('/register', async (req, res) => {
  const { firstname, lastname, email, password } = req.body;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      `INSERT INTO users (firstname, lastname, email, password_hash, is_active)
       VALUES ($1, $2, $3, $4, false)
       RETURNING id, email`,
      [firstname, lastname, email, hashedPassword]
    );
    const newUser = result.rows[0];

    const activationToken = jwt.sign({ userId: newUser.id }, JWT_SECRET, { expiresIn: '1d' });
    const activationLink = `${GOOGLE_REDIRECT_URI}/activate?token=${activationToken}`;

    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: 'udayhalankar@gmail.com',
        pass: 'YOUR_GMAIL_APP_PASSWORD'
      }
    });

    await transporter.sendMail({
      from: '"Your App" <youremail@gmail.com>',
      to: newUser.email,
      subject: 'Activate Your Account',
      html: `<p>Hi ${firstname},</p>
             <p>Please <a href="${activationLink}">click here</a> to activate your account.</p>`
    });

    res.status(201).json({ message: 'Registration successful. Please check your email.' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Registration failed' });
  }
});

/** ACTIVATE **/
router.get('/activate', async (req, res) => {
  try {
    const decoded = jwt.verify(req.query.token, JWT_SECRET);
    await pool.query('UPDATE users SET is_active = true WHERE id = $1', [decoded.userId]);
    res.redirect(`${GOOGLE_REDIRECT_URI}/login`);
  } catch (err) {
    console.error('Activation error:', err);
    res.status(400).send('Invalid or expired activation link.');
  }
});

/** LOGIN **/
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];

    if (!user) {
      await logAudit({
        userId: null,
        action: 'login_failed',
        tableName: 'users',
        details: { email, reason: 'User not found' },
      });
      return res.status(401).json({ message: 'User not found' });
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      await logAudit({
        userId: null,
        action: 'login_failed',
        tableName: 'users',
        details: { email, reason: 'Invalid password' },
      });
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    if (!user.is_active) {
      return res.status(403).json({ message: 'Activate your account first.' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, firstname: user.firstname, lastname: user.lastname
        ,
    lastActivity: Date.now()  // custom field - added by UH 26-7-25 4:40pm
       },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    await logAudit({
      userId: user.id,
      action: 'login',
      tableName: 'users',
      recordId: user.id,
      details: { email: user.email },
    });

    res.json({ token });
  } catch (err) {
    console.error('Login error:', err.message);
    res.status(500).json({ message: 'Login failed' });
  }
});

/** LOGOUT **/
router.post('/logout', async (req, res) => {
  try {
    const authHeader = req.headers['authorization'];
    if (!authHeader) return res.status(400).json({ message: 'No token provided' });

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET);

    await logAudit({
      userId: decoded.id,
      action: 'logout',
      tableName: 'users',
      recordId: decoded.id,
    });

    res.status(200).json({ message: 'Logged out successfully' });
  } catch (err) {
    console.error('Logout error:', err.message);
    res.status(400).json({ message: 'Logout failed' });
  }
});

/** PASSWORD CHANGE **/
router.post('/change-password', async (req, res) => {
  const { email, oldPassword, newPassword } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];

    if (!user) return res.status(404).json({ message: 'User not found' });

    const match = await bcrypt.compare(oldPassword, user.password_hash);
    if (!match) return res.status(401).json({ message: 'Old password incorrect' });

    const newHash = await bcrypt.hash(newPassword, 10);
    await pool.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, user.id]);

    await logAudit({
      userId: user.id,
      action: 'password_change',
      tableName: 'users',
      recordId: user.id,
    });

    res.json({ message: 'Password changed successfully' });
  } catch (err) {
    console.error('Change password error:', err.message);
    res.status(500).json({ message: 'Could not change password' });
  }
});

/** GOOGLE LOGIN **/
router.post('/google', async (req, res) => {
  const { idToken, code } = req.body;

  try {
    let ticket;

    if (idToken) {
      ticket = await client.verifyIdToken({ idToken, audience: GOOGLE_CLIENT_ID });
    } else {
      const { tokens } = await client.getToken({ code, redirect_uri: GOOGLE_REDIRECT_URI });
      ticket = await client.verifyIdToken({ idToken: tokens.id_token, audience: GOOGLE_CLIENT_ID });
    }

    const payload = ticket.getPayload();
    const { email, given_name: firstname, family_name: lastname, picture } = payload;

    let dbRes = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (dbRes.rows.length === 0) {
      const insert = await pool.query(
        `INSERT INTO users (firstname, lastname, email, password_hash, is_active)
         VALUES ($1, $2, $3, '', true)
         RETURNING *`,
        [firstname, lastname, email]
      );
      dbRes = insert;
    }

    const dbUser = dbRes.rows[0];

    const token = jwt.sign(
      { id: dbUser.id, email, firstname, lastname, picture,
    lastActivity: Date.now()  // custom field - added by UH 26-7-25 4:40pm
     },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    await logAudit({
      userId: dbUser.id,
      action: 'google_login',
      tableName: 'users',
      recordId: dbUser.id,
      details: { email },
    });

    res.json({ token });
  } catch (err) {
    console.error('❌ Google login error:', err.message);
    res.status(401).json({ message: 'Google authentication failed' });
  }
});

module.exports = router;


// // server/routes/auth.js
// require('dotenv').config();
// const express = require('express');
// const router = express.Router();
// const bcrypt = require('bcryptjs');
// const jwt = require('jsonwebtoken');
// const pool = require('../db');
// const nodemailer = require('nodemailer');
// const { OAuth2Client } = require('google-auth-library');
// const { logAudit } = require('../utils/auditLogger');

// // ───────────────── ENV ─────────────────
// const {
//   GOOGLE_CLIENT_ID,
//   GOOGLE_CLIENT_SECRET,
//   GOOGLE_REDIRECT_URI,      // Only for Google code exchange!
//   JWT_SECRET = 'YOUR_SECRET_KEY',
//   APP_BASE_URL = 'http://localhost:3000',  // <- Use THIS for activation/login redirects
//   SMTP_HOST,
//   SMTP_PORT = 587,
//   SMTP_SECURE = 'false',                    // "true" or "false" as string
//   SMTP_USER,
//   SMTP_PASS,
//   MAIL_FROM = 'no-reply@example.com',       // From address
// } = process.env;

// // normalize booleans
// const SMTP_SECURE_BOOL = String(SMTP_SECURE).toLowerCase() === 'true';

// // ──────────────── Google OAuth Client ────────────────
// const googleClient = new OAuth2Client(
//   GOOGLE_CLIENT_ID,
//   GOOGLE_CLIENT_SECRET,
//   GOOGLE_REDIRECT_URI && GOOGLE_REDIRECT_URI.trim()
// );

// // NOTE: prefer app-wide in server.js: app.use(express.json())
// // Keeping this here is okay if server doesn’t do it globally:
// router.use(express.json());

// // ──────────────── Mail Transport ────────────────
// const transporter = nodemailer.createTransport({
//   host: SMTP_HOST,
//   port: Number(SMTP_PORT),
//   secure: SMTP_SECURE_BOOL, // true for 465, false for 587/STARTTLS
//   auth: SMTP_USER && SMTP_PASS ? { user: SMTP_USER, pass: SMTP_PASS } : undefined,
// });

// // Quick helper
// const signToken = (user) =>
//   jwt.sign(
//     {
//       userId: user.id,                 // <- normalize claim name
//       email: user.email,
//       firstname: user.firstname || '',
//       lastname: user.lastname || '',
//       picture: user.picture || '',
//     },
//     JWT_SECRET,
//     { expiresIn: '1d' }                // longer, predictable lifetime
//   );

// // ───────────────── REGISTER ─────────────────
// router.post('/register', async (req, res) => {
//   const { firstname, lastname, email, password } = req.body || {};

//   try {
//     if (!firstname || !lastname || !email || !password) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     const cleanEmail = email.trim().toLowerCase();

//     // Enforce unique email
//     const exists = await pool.query(
//       'SELECT id FROM users WHERE LOWER(email) = $1',
//       [cleanEmail]
//     );
//     if (exists.rows.length) {
//       return res.status(409).json({ message: 'Email already registered' });
//     }

//     const passwordHash = await bcrypt.hash(password, 10);

//     const insert = await pool.query(
//       `INSERT INTO users (firstname, lastname, email, password_hash, is_active)
//        VALUES ($1, $2, $3, $4, false)
//        RETURNING id, email, firstname`,
//       [firstname, lastname, cleanEmail, passwordHash]
//     );
//     const newUser = insert.rows[0];

//     const activationToken = jwt.sign({ userId: newUser.id }, JWT_SECRET, { expiresIn: '1d' });
//     // Use APP_BASE_URL for your app—not GOOGLE_REDIRECT_URI
//     const activationLink = `${APP_BASE_URL.replace(/\/+$/, '')}/activate?token=${activationToken}`;

//     // Send activation email
//     await transporter.sendMail({
//       from: MAIL_FROM,
//       to: newUser.email,
//       subject: 'Activate Your Account',
//       html: `<p>Hi ${newUser.firstname},</p>
//              <p>Please <a href="${activationLink}">click here</a> to activate your account.</p>`,
//     });

//     res.status(201).json({ message: 'Registration successful. Please check your email.' });
//   } catch (err) {
//     console.error('Register error:', err);
//     res.status(500).json({ message: 'Registration failed' });
//   }
// });

// // ───────────────── ACTIVATE ─────────────────
// router.get('/activate', async (req, res) => {
//   try {
//     const token = String(req.query.token || '');
//     const decoded = jwt.verify(token, JWT_SECRET);

//     await pool.query('UPDATE users SET is_active = true WHERE id = $1', [decoded.userId]);

//     // After activation, send user to your app's login page
//     return res.redirect(`${APP_BASE_URL.replace(/\/+$/, '')}/login`);
//   } catch (err) {
//     console.error('Activation error:', err);
//     return res.status(400).send('Invalid or expired activation link.');
//   }
// });

// // ───────────────── LOGIN ─────────────────
// router.post('/login', async (req, res) => {
//   const { email, password } = req.body || {};
//   try {
//     if (!email || !password) {
//       return res.status(400).json({ message: 'Email and password are required' });
//     }

//     // ✅ Normalize email + select only needed columns
//     const cleanEmail = email.trim().toLowerCase();
//     const { rows } = await pool.query(
//       `SELECT id, email, password_hash, firstname, lastname, picture, is_active
//        FROM users
//        WHERE LOWER(email) = $1`,
//       [cleanEmail]
//     );

//     const user = rows[0];
//     if (!user) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     if (!user.is_active) {
//       return res.status(403).json({ message: 'Activate your account first.' });
//     }

//     // ✅ Guard: Google-only accounts have NULL password_hash
//     if (!user.password_hash) {
//       return res.status(401).json({ message: 'Use Google sign-in or set a password for this account' });
//     }

//     console.log('[LOGIN] querying user');
//     //const { rows } = await pool.query(/* ... */);
//     console.log('[LOGIN] query done rows=', rows.length);

//     console.log('[LOGIN] comparing hash');

//     // ✅ Compare AFTER the guard
//     const ok = await bcrypt.compare(password, user.password_hash);
//     console.log('[LOGIN] compare done ok=', ok);
//     if (!ok) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     // … your jwt.sign + logAudit + res.json({ token }) as you already have …
//   } catch (err) {
//     console.error('[LOGIN] failed:', err);
//     const dev = process.env.NODE_ENV !== 'production';
//     return res.status(500).json({ message: 'Login failed', ...(dev ? { reason: err.message } : {}) });
//   }
// });


// // ───────────────── LOGOUT ─────────────────
// // Stateless JWTs can't be truly "logged out" server-side without a denylist/TTL store.
// // We still audit the intent.
// router.post('/logout', async (req, res) => {
//   try {
//     const authHeader = req.headers['authorization'] || '';
//     const token = authHeader.split(' ')[1];
//     if (!token) return res.status(400).json({ message: 'No token provided' });

//     const decoded = jwt.verify(token, JWT_SECRET);

//     await logAudit?.({
//       userId: decoded.userId || decoded.id,
//       action: 'logout',
//       tableName: 'users',
//       recordId: decoded.userId || decoded.id,
//     }).catch(() => {});

//     return res.status(200).json({ message: 'Logged out successfully' });
//   } catch (err) {
//     console.error('Logout error:', err.message);
//     return res.status(400).json({ message: 'Logout failed' });
//   }
// });

// // ──────────────── PASSWORD CHANGE ────────────────
// router.post('/change-password', async (req, res) => {
//   const { email, oldPassword, newPassword } = req.body || {};
//   try {
//     if (!email || !oldPassword || !newPassword) {
//       return res.status(400).json({ message: 'Email, oldPassword, newPassword are required' });
//     }

//     const cleanEmail = email.trim().toLowerCase();
//     const { rows } = await pool.query(
//       `SELECT id, email, password_hash FROM users WHERE LOWER(email) = $1`,
//       [cleanEmail]
//     );
//     const user = rows[0];
//     if (!user) return res.status(404).json({ message: 'User not found' });
//     if (!user.password_hash) return res.status(400).json({ message: 'Password not set for this account' });

//     const ok = await bcrypt.compare(oldPassword, user.password_hash);
//     if (!ok) return res.status(401).json({ message: 'Old password incorrect' });

//     const newHash = await bcrypt.hash(newPassword, 10);
//     await pool.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, user.id]);

//     await logAudit?.({
//       userId: user.id,
//       action: 'password_change',
//       tableName: 'users',
//       recordId: user.id,
//     }).catch(() => {});

//     return res.json({ message: 'Password changed successfully' });
//   } catch (err) {
//     console.error('Change password error:', err.message);
//     return res.status(500).json({ message: 'Could not change password' });
//   }
// });

// // ──────────────── GOOGLE LOGIN ────────────────
// router.post('/google', async (req, res) => {
//   const { idToken, code } = req.body || {};

//   try {
//     if (!GOOGLE_CLIENT_ID || !GOOGLE_REDIRECT_URI) {
//       return res.status(500).json({ message: 'Google OAuth is not configured' });
//     }

//     let ticket;

//     if (idToken) {
//       ticket = await googleClient.verifyIdToken({
//         idToken,
//         audience: GOOGLE_CLIENT_ID,
//       });
//     } else if (code) {
//       // Exchange auth code for tokens; library knows redirect_uri from client if configured
//       const { tokens } = await googleClient.getToken({
//         code,
//         redirect_uri: GOOGLE_REDIRECT_URI.trim(),
//       });
//       ticket = await googleClient.verifyIdToken({
//         idToken: tokens.id_token,
//         audience: GOOGLE_CLIENT_ID,
//       });
//     } else {
//       return res.status(400).json({ message: 'idToken or code is required' });
//     }

//     const payload = ticket.getPayload();
//     const cleanEmail = String(payload.email || '').trim().toLowerCase();
//     const firstname = payload.given_name || '';
//     const lastname = payload.family_name || '';
//     const picture = payload.picture || '';

//     let dbRes = await pool.query(
//       `SELECT id, email, firstname, lastname, picture, is_active
//        FROM users WHERE LOWER(email) = $1`,
//       [cleanEmail]
//     );

//     if (dbRes.rows.length === 0) {
//       // Create Google-based account (no password_hash)
//       dbRes = await pool.query(
//         `INSERT INTO users (firstname, lastname, email, password_hash, picture, is_active)
//          VALUES ($1, $2, $3, NULL, $4, true)
//          RETURNING id, email, firstname, lastname, picture, is_active`,
//         [firstname, lastname, cleanEmail, picture]
//       );
//     } else {
//       // Optionally update picture/name changes from Google
//       const u = dbRes.rows[0];
//       if (picture && picture !== u.picture) {
//         await pool.query(`UPDATE users SET picture = $1 WHERE id = $2`, [picture, u.id]);
//       }
//     }

//     const dbUser = dbRes.rows[0];
//     const token = signToken({ ...dbUser, picture });

//     await logAudit?.({
//       userId: dbUser.id,
//       action: 'google_login',
//       tableName: 'users',
//       recordId: dbUser.id,
//       details: { email: cleanEmail },
//     }).catch(() => {});

//     return res.json({ token });
//   } catch (err) {
//     console.error('❌ Google login error:', err.message);
//     return res.status(401).json({ message: 'Google authentication failed' });
//   }
// });

// module.exports = router;
