import React from 'react'
import "./footer.scss"

const Footer = () => {
  return (
   
       <div className='footer'>
       <span>@Techtango</span>
       <span> Design Origins</span>
       </div>
    
  )
}

export default Footer