import React from 'react';
import "./docucontrol.scss";

export const Docucontrol = () => {
  return (
    <div>Dcsdcsdcsd</div>
  )

}

export default Docucontrol;
