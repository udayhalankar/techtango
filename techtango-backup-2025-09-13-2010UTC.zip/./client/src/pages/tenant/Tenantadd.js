import React from 'react'

export const Tenantadd = () => {
  return (
    <div>Addtenant</div>
  )
}

export default Tenantadd;
