// server/routes/workflows/assignmentswf.js
const express = require('express');
const router = express.Router();

const pool = require('../../db');
const { verifyToken } = require('../../middleware/authMiddleware');

// Require a valid JWT for all routes here
router.use(verifyToken);

// tiny query helper
async function q(sql, params = []) {
  const { rows } = await pool.query(sql, params);
  return rows;
}

/* ---------------------------------------------
 * WHOAMI: see what your token exposes
 * --------------------------------------------- */
router.get('/whoami', (req, res) => {
  res.json({ user: req.user ?? null });
});

/* ---------------------------------------------
 * Build WHERE scope for "inbox" based on user
 *
 * Priority:
 *  1) integer userId  → match assigned_to (int) OR assignee_id::int (safe cast)
 *  2) email → match assignee_email
 * Disable scoping: add ?all=1
 * --------------------------------------------- */
function buildInboxScope(req) {
  const all = (req.query?.all || '').toString().toLowerCase();
  if (all === '1' || all === 'true') {
    return { where: '', params: [] };
  }

  const userId = req.user?.userId ?? req.user?.id ?? null; // integer expected
  const email  = req.user?.email ?? req.user?.user_email ?? req.user?.mail ?? null;

  if (userId !== null && userId !== '') {
    // Safe-cast path: only cast assignee_id if it's all digits
    // (avoid invalid_text_representation on "::int")
    return {
      where:
        `WHERE (
           t.assigned_to = $1
           OR (t.assignee_id ~ '^[0-9]+$' AND t.assignee_id::int = $1)
         )`,
      params: [Number(userId)],
    };
  }

  if (email) {
    return { where: 'WHERE t.assignee_email = $1', params: [email] };
  }

  // No identity → show nothing (safer than leaking all)
  return { where: 'WHERE 1=0', params: [] };
}

/* ---------------------------------------------
 * INBOX: show tasks assigned to the logged-in user
 * Uses only workflow_tasks columns you provided
 * --------------------------------------------- */
router.get('/inbox', async (req, res) => {
  try {
    const { where, params } = buildInboxScope(req);

    // If you want to hide completed tasks, uncomment the AND clause below.
    const sql = `
      SELECT
        t.id                                    AS task_id,
        t.instance_id                           AS instance_id,
        t.node_id                               AS node_id,
        t.node_type                             AS node_type,
        t.form_id                               AS form_id,

        t.status                                AS task_status,
        t.completed_at                          AS completed_at,
        t.data                                  AS data,
        t.created_at                            AS created_at,
        t.updated_at                            AS updated_at,
        t.created_by                            AS created_by,
        t.modified_by                           AS modified_by,
        t.modified_at                           AS modified_at,
        t.workflow_id                           AS workflow_id,
        t.assignee_id                           AS assignee_id,
        t.assignee_email                        AS assignee_email,
        t.assigned_to                           AS assigned_to,
        COALESCE(t.started_at, t.created_at)    AS started_at

        -- UI-compat placeholders (no joins)
        , NULL::text                            AS instance_status
        , NULL::int                             AS record_id
        , 'Workflow'                            AS workflow_name
      FROM workflow_tasks t
      ${where}
      -- ${where ? 'AND' : 'WHERE'} t.completed_at IS NULL
      ORDER BY COALESCE(t.started_at, t.created_at) DESC
      LIMIT 200
    `;

    const rows = await q(sql, params);
    res.json(rows);
  } catch (err) {
    console.error('GET /inbox error:', err);
    res.status(500).json({ error: 'Failed to fetch inbox' });
  }
});

/* ---------------------------------------------
 * OUTBOX: "workflows I started"
 * Approximation without workflow_instances:
 *   group by instance_id where YOU are the creator
 * (created_by = your integer userId)
 * Supports ?all=1 to bypass scoping
 * --------------------------------------------- */
function buildOutboxScope(req) {
  const all = (req.query?.all || '').toString().toLowerCase();
  if (all === '1' || all === 'true') {
    return { clause: 'TRUE', params: [] }; // no scope
  }
  const userId = req.user?.userId ?? req.user?.id ?? null;
  if (userId !== null && userId !== '') {
    return { clause: 't.created_by = $1', params: [Number(userId)] };
  }
  // No identity → return none
  return { clause: 'FALSE', params: [] };
}

router.get('/outbox', async (req, res) => {
  try {
    const { clause, params } = buildOutboxScope(req);

    const sql = `
      WITH mine AS (
        SELECT
          t.instance_id,
          MIN(COALESCE(t.started_at, t.created_at)) AS started_at
        FROM workflow_tasks t
        WHERE ${clause}
        GROUP BY t.instance_id
      )
      SELECT
        m.instance_id,
        m.started_at,
        -- UI-compat placeholders
        NULL::text AS instance_status,
        'Workflow' AS workflow_name
      FROM mine m
      ORDER BY m.started_at DESC
      LIMIT 200
    `;

    const rows = await q(sql, params);
    res.json(rows);
  } catch (err) {
    console.error('GET /outbox error:', err);
    res.status(500).json({ error: 'Failed to fetch outbox' });
  }
});

module.exports = router;
