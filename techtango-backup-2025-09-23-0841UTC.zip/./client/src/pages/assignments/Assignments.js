import React from 'react';
import "./assignments.scss";

export const Assignments = () => {
  return (
    <div>Assignments</div>
  )
}

export default Assignments;