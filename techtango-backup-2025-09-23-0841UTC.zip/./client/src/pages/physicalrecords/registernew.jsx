import React, { useState } from "react";
import { Box, Button, Grid, MenuItem, TextField, Typography } from "@mui/material";


export default function RegisterNew({ onClose }){
const [form, setForm] = useState({
department: "",
fileId: "",
departmentFileId: "",
softCopy: null,
recordsClassification: "",
category: "",
objectType: "",
});


const set = (k) => (e) => setForm((s) => ({ ...s, [k]: e.target.value }));


return (
<Box>
<Typography variant="h6" gutterBottom>Register New Physical Object</Typography>
<Grid container spacing={2}>
<Grid item xs={12} md={6}><TextField label="Department" fullWidth value={form.department} onChange={set("department")} /></Grid>
<Grid item xs={12} md={6}><TextField label="File ID" fullWidth value={form.fileId} onChange={set("fileId")} /></Grid>
<Grid item xs={12}><TextField label="Department File ID" fullWidth value={form.departmentFileId} onChange={set("departmentFileId")} /></Grid>
<Grid item xs={12}><Button variant="outlined" component="label">Upload Soft Copy<input type="file" hidden /></Button></Grid>
<Grid item xs={12} md={6}><TextField label="Records Classification" select fullWidth value={form.recordsClassification} onChange={set("recordsClassification")}>
<MenuItem value="Finance Records">Finance Records</MenuItem>
</TextField></Grid>
<Grid item xs={12} md={6}><TextField label="Select Category" select fullWidth value={form.category} onChange={set("category")}>
<MenuItem value="Finance">Finance</MenuItem>
</TextField></Grid>
<Grid item xs={12} md={6}><TextField label="Object Type" select fullWidth value={form.objectType} onChange={set("objectType")}>
<MenuItem value="Box/Media">Box/Media</MenuItem>
</TextField></Grid>
<Grid item xs={12} md={6} textAlign="right"><Button variant="contained" onClick={onClose}>Save</Button></Grid>
</Grid>
</Box>
);
}