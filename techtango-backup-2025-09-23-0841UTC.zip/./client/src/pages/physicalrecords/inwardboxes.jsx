import React from "react";
import { Card, CardContent, Typography } from "@mui/material";


export default function InwardBoxes(){
return (
<Card><CardContent>
<Typography variant="h6">Inward Boxes</Typography>
<Typography variant="body2">Placeholder for inwarding boxes flow.</Typography>
</CardContent></Card>
);
}