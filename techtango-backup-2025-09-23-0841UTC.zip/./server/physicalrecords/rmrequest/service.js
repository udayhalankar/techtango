// server/rmrequest/service.js
const db = require("../../db");

// Helpers
const toDbBool = (v) => (v === true || v === "true") ? true : (v === false || v === "false") ? false : null;

module.exports = {
  /**
   * Search with pagination + filters
   * body: { text?, status?, type?, category?, dateFrom?, dateTo?, page?, pageSize?, sortBy?, sortDir? }
   */
  async search({
    text = "",
    status,
    type,
    category,
    dateFrom,
    dateTo,
    page = 1,
    pageSize = 10,
    sortBy = "date_created",
    sortDir = "desc",
  }) {
    const allowedSort = new Set([
      "request_id", "date_created", "request_status", "request_type"
    ]);
    if (!allowedSort.has(sortBy)) sortBy = "date_created";
    sortDir = (String(sortDir).toLowerCase() === "asc") ? "asc" : "desc";

    const where = [];
    const params = [];
    let i = 1;

    if (text) {
      where.push(`(
        request_type ILIKE $${i} OR
        request_status ILIKE $${i} OR
        delivered_to ILIKE $${i} OR
        primary_request_id ILIKE $${i} OR
        primary_request_type ILIKE $${i}
      )`);
      params.push(`%${text}%`); i++;
    }
    if (status) { where.push(`request_status = $${i}`); params.push(status); i++; }
    if (type)   { where.push(`request_type = $${i}`);   params.push(type);   i++; }
    if (category){where.push(`request_category = $${i}`);params.push(category);i++; }
    if (dateFrom){where.push(`date_created >= $${i}`);  params.push(dateFrom);i++; }
    if (dateTo)  {where.push(`date_created <  $${i}`);  params.push(dateTo);  i++; }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    const countSql = `SELECT COUNT(*)::int AS cnt FROM public.rm_request ${whereSql}`;
    const { rows: countRows } = await db.query(countSql, params);
    const total = countRows[0]?.cnt || 0;

    const offset = Math.max(0, (page - 1) * pageSize);

    const listSql = `
      SELECT
        request_id, tenant_id, sub_tenant_id,
        request_type, request_category, request_status,
        sub_tenantdept_code, requestor_id,
        primary_request_id, primary_request_type,
        req_cancel_reason,
        material_qty, material_quantity_issued,
        material_quantity_balance,
        audit_date_from, audit_date_to,
        was_delivery_validated, delivered_to,
        is_user_authenticated, user_ip, request_close_date,
        instructions,
        date_created, created_by, date_modified, modified_by
      FROM public.rm_request
      ${whereSql}
      ORDER BY ${sortBy} ${sortDir}
      LIMIT $${i} OFFSET $${i + 1}
    `;
    const { rows } = await db.query(listSql, [...params, pageSize, offset]);

    return {
      items: rows.map(r => ({
        id: String(r.request_id),
        requestId: r.request_id,
        tenantId: r.tenant_id,
        subTenantId: r.sub_tenant_id,
        requestType: r.request_type,
        requestCategory: r.request_category,
        requestStatus: r.request_status,
        subTenantdeptCode: r.sub_tenantdept_code,
        requestorId: r.requestor_id,
        primaryRequestID: r.primary_request_id,
        primaryRequestType: r.primary_request_type,
        reqCancelReason: r.req_cancel_reason,
        materialQty: r.material_qty,
        materialQuantityIssued: r.material_quantity_issued,
        materialQuantityBalance: r.material_quantity_balance,
        auditDateFrom: r.audit_date_from,
        auditDateTo: r.audit_date_to,
        wasDeliveryValidated: r.was_delivery_validated,
        deliveredTo: r.delivered_to,
        isUserAuthenticated: r.is_user_authenticated,
        userIP: r.user_ip,
        requestCloseDate: r.request_close_date,
        instructions: r.instructions,
        dateCreated: r.date_created,
        createdBy: r.created_by,
        dateModified: r.date_modified,
        modifiedBy: r.modified_by,
      })),
      page,
      pageSize,
      total,
      hasMore: offset + rows.length < total,
    };
  },

  /** Create */
  async create(body) {
    const q = `
      INSERT INTO public.rm_request (
        tenant_id, sub_tenant_id,
        request_type, request_category, request_status,
        sub_tenantdept_code, requestor_id,
        primary_request_id, primary_request_type,
        req_cancel_reason,
        material_qty, audit_date_from, audit_date_to,
        material_quantity_issued, was_delivery_validated,
        delivered_to, is_user_authenticated, user_ip,
        request_close_date, instructions,
        created_by, modified_by
      )
      VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
        $11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22
      )
      RETURNING request_id, date_created, date_modified
    `;
    const params = [
      body.tenantId ?? null,
      body.subTenantId ?? null,
      body.requestType ?? null,
      body.requestCategory ?? null,
      body.requestStatus ?? 'New',
      body.subTenantdeptCode ?? null,
      body.requestorId ?? null,
      body.primaryRequestID ?? null,
      body.primaryRequestType ?? null,
      body.reqCancelReason ?? null,
      body.materialQty ?? null,
      body.auditDateFrom ?? null,
      body.auditDateTo ?? null,
      body.materialQuantityIssued ?? null,
      body.wasDeliveryValidated ?? null,
      body.deliveredTo ?? null,
      body.isUserAuthenticated ?? null,
      body.userIP ?? null,
      body.requestCloseDate ?? null,
      body.instructions ?? null,
      body.createdBy ?? null,
      body.modifiedBy ?? null,
    ];
    const { rows } = await db.query(q, params);
    return { ok: true, id: rows[0].request_id, dateCreated: rows[0].date_created, dateModified: rows[0].date_modified };
  },

  /** Get one */
  async getById(id) {
    const { rows } = await db.query(
      `SELECT * FROM public.rm_request WHERE request_id = $1`,
      [id]
    );
    return rows[0] || null;
  },

  /** Patch (partial update) */
  async patch(id, body) {
    // Build dynamic SET list
    const sets = [];
    const params = [];
    let i = 1;

    const map = {
      tenant_id: body.tenantId,
      sub_tenant_id: body.subTenantId,
      request_type: body.requestType,
      request_category: body.requestCategory,
      request_status: body.requestStatus,
      sub_tenantdept_code: body.subTenantdeptCode,
      requestor_id: body.requestorId,
      primary_request_id: body.primaryRequestID,
      primary_request_type: body.primaryRequestType,
      req_cancel_reason: body.reqCancelReason,
      material_qty: body.materialQty,
      audit_date_from: body.auditDateFrom,
      audit_date_to: body.auditDateTo,
      material_quantity_issued: body.materialQuantityIssued,
      was_delivery_validated: body.wasDeliveryValidated,
      delivered_to: body.deliveredTo,
      is_user_authenticated: body.isUserAuthenticated,
      user_ip: body.userIP,
      request_close_date: body.requestCloseDate,
      instructions: body.instructions,
      modified_by: body.modifiedBy,
    };

    Object.entries(map).forEach(([col, val]) => {
      if (val !== undefined) {
        sets.push(`${col} = $${i++}`);
        params.push(val);
      }
    });

    if (!sets.length) return { ok: true, updated: 0 };

    const sql = `UPDATE public.rm_request SET ${sets.join(", ")} WHERE request_id = $${i} RETURNING request_id`;
    params.push(id);

    const { rowCount } = await db.query(sql, params);
    return { ok: true, updated: rowCount };
  },

  /** Update only status */
  async updateStatus(id, requestStatus) {
    const { rowCount } = await db.query(
      `UPDATE public.rm_request SET request_status = $1 WHERE request_id = $2`,
      [requestStatus, id]
    );
    return { ok: true, updated: rowCount };
  },

  /** Delete */
  async remove(id) {
    const { rowCount } = await db.query(`DELETE FROM public.rm_request WHERE request_id = $1`, [id]);
    return { ok: true, deleted: rowCount };
  },
};
