import React from 'react';

export const Feedback = () => {
  return (
    <div>Feedback

    </div>
   
  )
}

export default Feedback;
