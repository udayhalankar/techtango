const db = require("../../db");

// Decide the target file_status for the request type
function targetFileStatus(reqTypeRaw) {
  const t = String(reqTypeRaw || "").toLowerCase();
  if (t === "file refiling request" || t === "refiling") return "IN";
  return "OUT"; // File Retrieval, Audit, Insertion, Permout Delivery/Destruction, File Inward, etc.
}

// Next request status after a processing click
function nextRequestStatus(total, processedNow, totalProcessedAfter) {
  // If everything is processed after this run -> Ready for Delivery, else In-progress
  return totalProcessedAfter >= total ? "Ready_for_Delivery" : "In-progress";
}

exports.getInfo = async function getInfo(requestId) {
  // basic request row
  const rq = await db.query(
    `SELECT request_id, request_type, sub_tenantdept_code, request_status, requestor_id
       FROM public.rm_request
      WHERE request_id = $1`,
    [requestId]
  );
  if (!rq.rows[0]) throw new Error("Request not found");
  const r = rq.rows[0];

  // derive tenant/subdept/tenantName from any file of this request
  const fx = await db.query(
    `SELECT tenantid, subtenantdeptcode, binid
       FROM public.rmfilemaster
      WHERE requestid = $1
      LIMIT 1`, [requestId]
  );
  const tenantId = fx.rows[0]?.tenantid ?? null;
  const subDept  = r.subtenantdeptcode ?? fx.rows[0]?.subtenantdeptcode ?? null;

  // 🔹 your actual table & column names
  let tenantName = "";
  if (tenantId != null) {
    const tn = await db.query(
      `SELECT tenantname AS name
         FROM public.tenants
        WHERE id = $1`,
      [tenantId]
    );
    tenantName = tn.rows[0]?.name || String(tenantId);
  }
  
  // try best-effort tenant name lookup (rename table/column if different in your DB)
  const tn = await db.query(
    `SELECT tenantname FROM public.tenants WHERE id = $1`,
    [tenantId]
  ).catch(() => ({ rows: [] }));
  //const tenantName = tn.rows[0]?.name || (tenantId ? String(tenantId) : "");

  // pending = files for this request NOT already at target status
  const tgt = targetFileStatus(r.request_type);
  const pending = await db.query(
    `SELECT COUNT(*)::int AS cnt
       FROM public.rmfilemaster
      WHERE requestid = $1
        AND COALESCE(filestatus,'') <> $2`,
    [requestId, tgt]
  );

  return {
    requestId: r.requestid,
    requestType: r.request_type,
    tenantName,
    subDept,
    pendingCount: pending.rows[0]?.cnt ?? 0,
  };
};

exports.validateBox = async function validateBox(requestId, boxBarcode) {
  if (!boxBarcode) return { ok: false, error: "Box barcode required" };
  const q = await db.query(
    `SELECT binid
       FROM public.rmfilemaster
      WHERE requestid = $1 AND (binid = $2)
      LIMIT 1`,
    [requestId, boxBarcode]
  );
  if (!q.rows[0]) return { ok: false, error: "Box not part of this request" };
  return { ok: true, canonical: q.rows[0].binid };
};

exports.validateFile = async function validateFile(requestId, fileBarcode, boxBarcode) {
  if (!fileBarcode) return { ok: false, error: "File barcode required" };

  // require file to belong to this request (and optionally to the active box)
  const whereBox = boxBarcode ? ` AND (binid = $3 OR binid = $3)` : "";
  const params = boxBarcode ? [requestId, fileBarcode, boxBarcode] : [requestId, fileBarcode];

  const q = await db.query(
    `SELECT fileid, COALESCE(binid,'') AS binid, COALESCE(deptfileid, fileid)::text AS label,
            COALESCE(filestatus,'') AS status
       FROM public.rmfilemaster
      WHERE requestid = $1
        AND (fileid = $2 OR deptfileid = $2)
      ${whereBox}
      LIMIT 1`,
    params
  );
  if (!q.rows[0]) return { ok: false, error: "File not part of this request (or wrong box)" };
  return { ok: true, file: { fileId: q.rows[0].fileid, boxId: q.rows[0].binid, label: q.rows[0].label } };
};

exports.processFiles = async function processFiles(requestId, fileIds, user) {
  if (!Array.isArray(fileIds) || !fileIds.length) return { ok: false, error: "No files provided" };

  const rq = await db.query(
    `SELECT request_type FROM public.rm_request WHERE request_id=$1`, [requestId]
  );
  if (!rq.rows[0]) throw new Error("Request not found");

  const tgt = targetFileStatus(rq.rows[0].request_type);

  try {
    await db.query("BEGIN");

    // total files in request
    const totalQ = await db.query(
      `SELECT COUNT(*)::int AS cnt FROM public.rmfilemaster WHERE requestid = $1`,
      [requestId]
    );
    const total = totalQ.rows[0]?.cnt || 0;

    // mark selected files to target status
    const upd = await db.query(
      `UPDATE public.rmfilemaster
          SET filestatus = $2, date_modified = NOW()
        WHERE requestid = $1
          AND fileid = ANY($3::text[])`,
      [requestId, tgt, fileIds]
    );
    const processed = upd.rowCount || 0;

    // how many now at target status (after this update)
    const atTgt = await db.query(
      `SELECT COUNT(*)::int AS cnt
         FROM public.rmfilemaster
        WHERE requestid = $1
          AND COALESCE(filestatus,'') = $2`,
      [requestId, tgt]
    );
    const totalProcessedAfter = atTgt.rows[0]?.cnt || 0;

    // bump request status
    const newReqStatus = nextRequestStatus(total, processed, totalProcessedAfter);
    await db.query(
      `UPDATE public.rm_request
          SET request_status = $2, modified_by = $3, date_modified = NOW()
        WHERE request_id = $1`,
      [requestId, newReqStatus, user?.id ?? null]
    );

    // create a Delivery Request once (idempotent)
    let deliveryRequestId = null;
    const exists = await db.query(
      `SELECT request_id FROM public.rm_request
        WHERE primary_request_id = $1 AND request_type = 'Delivery' LIMIT 1`,
      [requestId]
    );
    if (!exists.rows[0]) {
      const ins = await db.query(
        `INSERT INTO public.rm_request
           (request_type, request_category, request_status,
            primary_request_id, primary_request_type,
            created_by, modified_by)
         SELECT 'Delivery', r.request_category, 'New',
                r.request_id, r.request_type,
                $2, $2
           FROM public.rm_request r
          WHERE r.request_id = $1
         RETURNING request_id`,
        [requestId, user?.id ?? null]
      );
      deliveryRequestId = ins.rows[0]?.request_id || null;
    }

    await db.query("COMMIT");
    return { ok: true, processed, requestStatus: newReqStatus, deliveryRequestId };
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  }
};
